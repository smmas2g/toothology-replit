# Overview

This is a comprehensive dental practice website built with React (frontend) and Express.js (backend). The application provides a full-featured web presence for a dental clinic called "SmileCare Dental" with patient-facing pages, content management capabilities, and administrative features. The site includes service listings, team information, patient testimonials, a blog, image gallery, contact forms, and patient portal functionality.

The application now features a PostgreSQL database for data persistence and uses a static geometric tooth logo throughout the website for immediate loading and optimal performance.

# User Preferences

Preferred communication style: Simple, everyday language.

## Button Design System Requirements
- Dental-themed color hierarchy with medical blue primary, white secondary with borders, text tertiary links
- Mobile-first design with minimum 44px touch targets for accessibility
- Consistent spacing (gap-4) and logical placement throughout website
- Clear visual hierarchy: primary for appointments/calls, secondary for navigation, tertiary for footer links
- Emergency contact buttons prominently displayed with red gradient colors

## Performance & Loading Requirements
- No loading animations or intro screens - immediate content display
- Static geometric tooth logo (SVG-based) for fast loading
- Removed all animation delays and loading overlays
- Optimized for instant website access and improved Core Web Vitals

## Pricing Strategy
- No pricing displayed on website - contact-only pricing model
- All service cards show "Free Consultation Available" instead of prices
- Phone number (0208 642 9345) prominently displayed for pricing inquiries
- "Call for personalized pricing" messaging throughout website
- Payment plan and insurance information highlighted
- Written quotations provided after examination

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with file-based page organization
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dental-themed color variables and responsive design
- **Animations**: Framer Motion for smooth page transitions and interactive elements
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Forms**: React Hook Form with Zod validation for type-safe form handling

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **API Design**: RESTful API structure with organized route handlers
- **Database Layer**: Drizzle ORM with PostgreSQL database using Neon as the provider
- **Development Setup**: Hot module replacement with Vite integration for seamless development
- **Error Handling**: Centralized error handling middleware with structured error responses
- **Request Logging**: Custom middleware for API request/response logging and performance monitoring

## Database Design
- **Database**: PostgreSQL hosted on Neon (serverless)
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Connection**: Neon serverless database with WebSocket support
- **Schema Structure**: Comprehensive schema covering:
  - Services (dental procedures and treatments)
  - Team members (dentists and staff)
  - Testimonials (patient reviews and ratings)
  - Blog posts (content management)
  - Gallery images (before/after photos)
  - Contact submissions (patient inquiries)
- **Data Types**: Uses UUID primary keys, timestamps, arrays for lists, and proper relational structure
- **Migrations**: Managed through Drizzle Kit for database schema versioning
- **Seeding**: Automated seeding script populates database with initial dental practice data

## Component Architecture
- **Design System**: Consistent component library with dental-themed button variants and comprehensive theming system
- **Button System**: Comprehensive hierarchy with primary (medical blue), call (green), emergency (red), dental (brand colors), secondary (white with border), and tertiary (text links) variants
- **Mobile Optimization**: All buttons include mobile-specific sizes (mobile, mobile-lg) with minimum 44px touch targets
- **Layout Components**: Reusable navigation, footer, and page layout components with consistent button styling
- **Page Components**: Dedicated components for each route (Home, Services, About, etc.) with proper button placement
- **UI Components**: Comprehensive set of accessible components (forms, dialogs, cards, etc.) using the unified button system
- **Responsive Design**: Mobile-first approach with breakpoint-specific layouts and touch-friendly interactions

## Authentication & Security
- **Session Management**: Express sessions with PostgreSQL session store
- **Form Validation**: Client-side and server-side validation using Zod schemas
- **CORS Configuration**: Proper cross-origin resource sharing setup
- **Input Sanitization**: Protected against common web vulnerabilities

# External Dependencies

## Database & ORM
- **Neon Database**: Serverless PostgreSQL database provider
- **Drizzle ORM**: Type-safe database toolkit with migrations
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## UI & Styling
- **Radix UI**: Accessible component primitives for complex UI elements
- **Tailwind CSS**: Utility-first CSS framework with custom theming
- **Lucide React**: Icon library for consistent iconography
- **Framer Motion**: Animation library for smooth user interactions

## Development Tools
- **Vite**: Fast build tool with HMR and optimized production builds
- **TypeScript**: Static type checking for both frontend and backend
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment optimizations and error handling

## Form & Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **@hookform/resolvers**: Integration between React Hook Form and Zod

## State Management
- **TanStack Query**: Server state management with caching, background updates, and optimistic updates
- **React Context**: Client-side state management for UI state

## Additional Services
- **Date-fns**: Date manipulation and formatting library
- **Nanoid**: URL-safe unique ID generator
- **Class Variance Authority**: Utility for creating variant-based component APIs