import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Phone, Calendar, AlertTriangle, X } from "lucide-react";

export default function MobileBottomBar() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <>
      {/* Mobile bottom navigation bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden">
        <motion.div 
          className="bg-white border-t border-dental-beige shadow-lg"
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center justify-around p-2">
            {/* Call button */}
            <motion.a
              href="tel:02086429345"
              className="flex flex-col items-center p-2 rounded-lg bg-gradient-to-r from-green-600 to-green-700 text-white min-h-[44px] min-w-[44px] flex-1 mx-1 shadow-lg"
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.02 }}
            >
              <Phone className="h-4 w-4 mb-1" />
              <span className="text-xs font-medium">Call</span>
            </motion.a>

            {/* Book appointment button */}
            <motion.button
              onClick={() => {
                const element = document.getElementById('contact');
                if (element) {
                  element.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="flex flex-col items-center p-2 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white min-h-[44px] min-w-[44px] flex-1 mx-1 shadow-lg"
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.02 }}
            >
              <Calendar className="h-4 w-4 mb-1" />
              <span className="text-xs font-medium">Book</span>
            </motion.button>

            {/* Emergency button */}
            <motion.button
              onClick={() => setIsExpanded(true)}
              className="flex flex-col items-center p-2 rounded-lg bg-gradient-to-r from-red-600 to-red-700 text-white min-h-[44px] min-w-[44px] flex-1 mx-1 shadow-lg"
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.02 }}
            >
              <AlertTriangle className="h-4 w-4 mb-1" />
              <span className="text-xs font-medium">Emergency</span>
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Emergency overlay */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            className="fixed inset-0 z-50 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setIsExpanded(false)}
            />
            
            {/* Emergency content */}
            <motion.div
              className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl p-6"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-dental-dark">Dental Emergency</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsExpanded(false)}
                  className="min-h-[44px] min-w-[44px]"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
              
              <div className="space-y-4">
                <p className="text-dental-text mb-4">
                  For dental emergencies outside of office hours:
                </p>
                
                <a href="tel:02086429345" onClick={() => setIsExpanded(false)}>
                  <Button
                    variant="emergency"
                    size="mobile-lg"
                    className="w-full justify-start"
                  >
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mr-4">
                      <Phone className="h-6 w-6 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold">Emergency Line</div>
                      <div className="text-sm opacity-90">0208 642 9345</div>
                    </div>
                  </Button>
                </a>
                
                <div className="text-sm text-dental-text">
                  <p className="font-medium mb-2">In case of severe dental trauma:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Call 999 for life-threatening emergencies</li>
                    <li>Visit your nearest A&E for facial injuries</li>
                    <li>Contact our emergency line for dental pain</li>
                  </ul>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}