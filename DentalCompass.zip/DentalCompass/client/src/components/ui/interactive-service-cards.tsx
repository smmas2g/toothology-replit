import { useState, useRef, useEffect } from "react";
import { motion, useAnimation, useInView, useTransform, useMotionValue } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  Heart, 
  Smile, 
  Shield,
  Star,
  Stethoscope,
  CheckCircle,
  ArrowRight,
  Sparkles,
  RotateCcw,
  Activity,
  Brush,
  Crown,
  Zap
} from "lucide-react";
import type { Service } from "@shared/schema";

// Service icon mapping with specific animations
const serviceIconMap = {
  "invisalign": { 
    Icon: RotateCcw, 
    color: "from-blue-500 to-cyan-500",
    hoverColor: "from-blue-400 to-cyan-400",
    animation: "rotate"
  },
  "dental-implants": { 
    Icon: Shield, 
    color: "from-green-500 to-emerald-500",
    hoverColor: "from-green-400 to-emerald-400",
    animation: "bounce"
  },
  "cosmetic-dentistry": { 
    Icon: Sparkles, 
    color: "from-purple-500 to-pink-500",
    hoverColor: "from-purple-400 to-pink-400",
    animation: "sparkle"
  },
  "periodontics": { 
    Icon: Activity, 
    color: "from-red-500 to-rose-500",
    hoverColor: "from-red-400 to-rose-400",
    animation: "pulse"
  },
  "root-canal": { 
    Icon: Heart, 
    color: "from-orange-500 to-amber-500",
    hoverColor: "from-orange-400 to-amber-400",
    animation: "heartbeat"
  },
  "dental-hygienist": { 
    Icon: Brush, 
    color: "from-teal-500 to-cyan-500",
    hoverColor: "from-teal-400 to-cyan-400",
    animation: "sweep"
  }
};

// 3D tilt effect hook
const use3DTilt = () => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-100, 100], [30, -30]);
  const rotateY = useTransform(x, [-100, 100], [-30, 30]);

  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    x.set((event.clientX - centerX) / 5);
    y.set((event.clientY - centerY) / 5);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return { rotateX, rotateY, handleMouseMove, handleMouseLeave };
};

// Individual service card component
const InteractiveServiceCard = ({ service, index }: { service: Service; index: number }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [showPrice, setShowPrice] = useState(false);
  const cardRef = useRef(null);
  const isInView = useInView(cardRef, { once: true });
  const controls = useAnimation();
  
  const { rotateX, rotateY, handleMouseMove, handleMouseLeave } = use3DTilt();

  // Get service config or use default
  const serviceConfig = serviceIconMap[service.slug as keyof typeof serviceIconMap] || {
    Icon: Star,
    color: "from-gray-500 to-gray-600",
    hoverColor: "from-gray-400 to-gray-500",
    animation: "bounce"
  };

  const { Icon, color, hoverColor, animation } = serviceConfig;

  // Animation variants for different icon types
  const iconAnimations = {
    rotate: {
      animate: { rotate: 360 },
      transition: { duration: 2, repeat: Infinity, ease: "linear" }
    },
    bounce: {
      animate: { y: [0, -10, 0] },
      transition: { duration: 1.5, repeat: Infinity }
    },
    sparkle: {
      animate: { 
        scale: [1, 1.2, 1],
        rotate: [0, 180, 360]
      },
      transition: { duration: 2, repeat: Infinity }
    },
    pulse: {
      animate: { 
        scale: [1, 1.1, 1],
        opacity: [1, 0.8, 1]
      },
      transition: { duration: 1.5, repeat: Infinity }
    },
    heartbeat: {
      animate: { 
        scale: [1, 1.2, 1, 1.1, 1]
      },
      transition: { duration: 2, repeat: Infinity }
    },
    sweep: {
      animate: { 
        x: [0, 10, -10, 0],
        rotate: [0, 15, -15, 0]
      },
      transition: { duration: 2, repeat: Infinity }
    }
  };

  useEffect(() => {
    if (isInView) {
      controls.start("visible");
    }
  }, [isInView, controls]);

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.9
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        delay: index * 0.1,
        ease: "easeOut"
      }
    }
  };

  // Contact information for pricing inquiries
  const contactInfo = {
    phone: "0208 642 9345",
    message: "Call for personalized pricing",
    consultation: "Free consultation available"
  };

  // Treatment duration information (keeping medical timing)
  const treatmentDuration = {
    "invisalign": { duration: "12-18 months", consultation: true },
    "dental-implants": { duration: "3-6 months", consultation: true },
    "cosmetic-dentistry": { duration: "2-4 weeks", consultation: true },
    "periodontics": { duration: "4-8 weeks", consultation: true },
    "root-canal": { duration: "1-2 visits", consultation: true },
    "dental-hygienist": { duration: "1 hour", consultation: false }
  };

  const serviceDuration = treatmentDuration[service.slug as keyof typeof treatmentDuration] || { 
    duration: "Varies", 
    consultation: true 
  };

  return (
    <motion.div
      ref={cardRef}
      variants={cardVariants}
      initial="hidden"
      animate={controls}
      whileHover={{ y: -10 }}
      className="group perspective-1000"
    >
      <motion.div
        style={{
          rotateX,
          rotateY,
          transformStyle: "preserve-3d"
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => {
          handleMouseLeave();
          setIsHovered(false);
          setShowPrice(false);
        }}
        onMouseEnter={() => {
          setIsHovered(true);
          setTimeout(() => setShowPrice(true), 300);
        }}
        className="relative"
      >
        <Card className="relative h-full bg-white border-0 shadow-lg overflow-hidden transition-all duration-500 group-hover:shadow-2xl">
          {/* Consultation badge */}
          {serviceDuration.consultation && (
            <motion.div
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              className="absolute top-4 right-4 z-10"
            >
              <Badge 
                className="bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold shadow-lg"
              >
                <motion.div
                  animate={{
                    boxShadow: [
                      "0 0 0 0 rgba(34, 197, 94, 0.4)",
                      "0 0 0 10px rgba(34, 197, 94, 0)",
                      "0 0 0 0 rgba(34, 197, 94, 0)"
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  ✓ Free Consult
                </motion.div>
              </Badge>
            </motion.div>
          )}

          {/* Gradient background overlay */}
          <motion.div
            className={`absolute inset-0 bg-gradient-to-br ${isHovered ? hoverColor : color} opacity-0 transition-all duration-500`}
            animate={{ opacity: isHovered ? 0.1 : 0 }}
          />

          <CardContent className="p-8 relative z-10">
            {/* Icon with animation */}
            <motion.div
              className={`w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br ${color} flex items-center justify-center shadow-lg`}
              whileHover={{ scale: 1.1 }}
              animate={isHovered ? iconAnimations[animation as keyof typeof iconAnimations].animate : {}}
              transition={isHovered ? iconAnimations[animation as keyof typeof iconAnimations].transition : {}}
            >
              <Icon className="h-10 w-10 text-white" />
            </motion.div>

            {/* Service title */}
            <motion.h3 
              className="text-xl font-bold text-dental-dark mb-4 text-center"
              animate={{ color: isHovered ? "#6B7280" : "#1F2937" }}
            >
              {service.title}
            </motion.h3>

            {/* Service description */}
            <motion.p 
              className="text-dental-text mb-6 text-center leading-relaxed"
              animate={{ scale: isHovered ? 1.02 : 1 }}
            >
              {service.description}
            </motion.p>

            {/* Features list */}
            <div className="mb-6">
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ 
                  height: isHovered ? "auto" : 120,
                  opacity: 1
                }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <h4 className="font-medium text-dental-dark mb-3 text-sm">What's included:</h4>
                <ul className="space-y-2">
                  {service.features.slice(0, 3).map((feature, i) => (
                    <motion.li 
                      key={i}
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className="text-sm text-dental-text flex items-center"
                    >
                      <motion.div
                        animate={{ rotate: isHovered ? 360 : 0 }}
                        transition={{ duration: 0.5 }}
                      >
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                      </motion.div>
                      {feature}
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            </div>

            {/* Contact for pricing and duration info */}
            <motion.div 
              className="mb-6 text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: showPrice ? 1 : 0,
                y: showPrice ? 0 : 20
              }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-lg font-bold text-dental-dark mb-2">
                {serviceDuration.consultation ? "Free Consultation Available" : "Professional Care"}
              </div>
              <div className="text-sm text-dental-grey mb-2">
                Treatment Duration: {serviceDuration.duration}
              </div>
              <div className="text-sm font-medium text-dental-dark">
                Call {contactInfo.phone} for pricing
              </div>
            </motion.div>

            {/* Action buttons */}
            <div className="space-y-3">
              <Link href={`/services/${service.slug}`}>
                <Button 
                  variant="primary"
                  size="mobile-lg"
                  className="w-full"
                >
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              
              <Button
                variant="call"
                size="mobile-lg"
                className="w-full"
                onClick={() => window.open(`tel:${contactInfo.phone}`, '_self')}
              >
                Call {contactInfo.phone}
              </Button>
              
              <motion.button
                className="w-full text-dental-dark border border-dental-beige hover:bg-dental-beige transition-colors duration-300 py-2 px-4 rounded-lg text-sm"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowPrice(!showPrice)}
              >
                {showPrice ? "Hide Details" : "Show Treatment Info"}
              </motion.button>
            </div>
          </CardContent>

          {/* 3D depth shadow */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl -z-10"
            style={{
              transform: "translateZ(-50px)",
              transformStyle: "preserve-3d"
            }}
            animate={{
              opacity: isHovered ? 0.3 : 0,
              scale: isHovered ? 1.02 : 1
            }}
          />
        </Card>
      </motion.div>
    </motion.div>
  );
};

// Main interactive service cards component
export default function InteractiveServiceCards() {
  const { data: services, isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  if (isLoading) {
    return (
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <div className="h-12 bg-dental-beige rounded mb-6 w-2/3 mx-auto animate-pulse"></div>
            <div className="h-6 bg-dental-beige rounded mb-4 w-1/2 mx-auto animate-pulse"></div>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-dental-beige rounded-2xl p-8 animate-pulse h-96">
                <div className="w-20 h-20 bg-dental-beige-light rounded-full mb-6 mx-auto"></div>
                <div className="h-6 bg-dental-beige-light rounded mb-4"></div>
                <div className="space-y-2 mb-6">
                  <div className="h-4 bg-dental-beige-light rounded"></div>
                  <div className="h-4 bg-dental-beige-light rounded w-3/4"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 md:py-16 lg:py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.h2 
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-dental-dark mb-6 leading-tight"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Our Premium <span className="text-dental-grey">Services</span>
          </motion.h2>
          <motion.p 
            className="text-lg text-dental-text max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            Experience world-class dental care with our comprehensive range of treatments. 
            Each service is designed with your comfort and satisfaction in mind.
          </motion.p>
        </motion.div>

        {/* Interactive service cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {services?.map((service, index) => (
            <InteractiveServiceCard
              key={service.id}
              service={service}
              index={index}
            />
          ))}
        </div>

        {/* CTA section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/contact">
                <Button 
                  variant="primary"
                  size="mobile-lg"
                  className="w-full sm:w-auto shadow-xl hover:shadow-2xl"
                >
                  <span className="mr-2">📅</span>
                  Book Appointment
                </Button>
              </Link>
              <a href="tel:02086429345">
                <Button 
                  variant="call"
                  size="mobile-lg"
                  className="w-full sm:w-auto shadow-xl hover:shadow-2xl"
                >
                  <span className="mr-2">📞</span>
                  Call: 0208 642 9345
                </Button>
              </a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}