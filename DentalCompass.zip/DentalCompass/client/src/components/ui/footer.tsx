import { Link } from "wouter";
import { Heart, Facebook, Instagram } from "lucide-react";
import { FaGoogle } from "react-icons/fa";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { StaggeredFadeIn } from "@/components/ui/animated-elements";
import ToothLogo from "@/components/ui/tooth-logo";

export default function Footer() {
  return (
    <footer className="bg-dental-dark text-white py-12 relative overflow-hidden">
      {/* Animated background elements */}
      <motion.div
        className="absolute inset-0 opacity-5"
        animate={{ rotate: 360 }}
        transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
      >
        <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full blur-2xl"></div>
        <div className="absolute bottom-10 right-10 w-48 h-48 bg-dental-beige rounded-full blur-3xl"></div>
      </motion.div>
      
      <div className="container mx-auto px-4 md:px-6 lg:px-8 relative">
        <StaggeredFadeIn className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mb-6 md:mb-8" staggerDelay={0.1}>
          {/* Company Info */}
          <div className="space-y-4 text-center md:text-left">
            <ToothLogo size="md" className="justify-center md:justify-start text-white" showText={true} />
            <p className="text-gray-300 leading-relaxed text-sm md:text-base">
              Providing exceptional dental care with modern technology and a
              patient-first approach at Cheam Road, Sutton.
            </p>
            <div className="flex space-x-4 justify-center md:justify-start">
              {[
                { icon: Facebook, href: "#", label: "Facebook" },
                { icon: Instagram, href: "#", label: "Instagram" },
                { icon: FaGoogle, href: "#", label: "Google Reviews" }
              ].map((social, index) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 min-w-[40px] min-h-[40px] bg-dental-grey rounded-full flex items-center justify-center hover:bg-white hover:text-dental-dark transition-colors"
                  whileHover={{ 
                    scale: 1.2, 
                    y: -3,
                    rotate: [0, -5, 5, 0]
                  }}
                  whileTap={{ scale: 0.9 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ 
                    delay: index * 0.1,
                    hover: { duration: 0.3 }
                  }}
                >
                  <social.icon className="h-4 w-4" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-3 md:mb-4 text-base md:text-lg">Quick Links</h4>
            <div className="space-y-2">
              <Link href="/">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base">
                  Home
                </Button>
              </Link>
              <Link href="/services">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Services
                </Button>
              </Link>
              <Link href="/about">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  About
                </Button>
              </Link>
              <Link href="/gallery">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Gallery
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Contact
                </Button>
              </Link>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <div className="space-y-2">
              <Link href="/services/invisalign">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Invisalign
                </Button>
              </Link>
              <Link href="/services/dental-implants">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Dental Implants
                </Button>
              </Link>
              <Link href="/services/cosmetic-dentistry">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Cosmetic Dentistry
                </Button>
              </Link>
              <Link href="/services/periodontics">
                <Button variant="tertiary" className="justify-start p-0 h-auto text-sm md:text-base text-gray-300 hover:text-white">
                  Periodontics
                </Button>
              </Link>
              <div className="mt-3 space-y-1">
                <p className="text-xs text-gray-400">
                  Call 0208 642 9345 for pricing
                </p>
                <p className="text-xs text-green-400">
                  Free consultations available
                </p>
              </div>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4">Contact Info</h4>
            <div className="space-y-2 text-gray-300">
              <p className="flex items-center">
                <span className="mr-2">📍</span>
                125 Cheam Road, Sutton, SM1 2BH
              </p>
              <p className="flex items-center">
                <span className="mr-2">📞</span>
                <a href="tel:02086429345" className="hover:text-white transition-colors">
                  0208 642 9345
                </a>
              </p>
              <p className="flex items-center">
                <span className="mr-2">✉️</span>
                <a href="mailto:admin@cheamdental.co.uk" className="hover:text-white transition-colors">
                  admin@cheamdental.co.uk
                </a>
              </p>
            </div>
          </div>
        </StaggeredFadeIn>

        <div className="border-t border-dental-grey pt-8">
          <motion.div
            className="flex flex-col md:flex-row justify-between items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <p className="text-gray-300 mb-4 md:mb-0">
              &copy; 2024 Toothology Cheam Road. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              {["Privacy Policy", "Terms of Service", "Accessibility"].map((link, index) => (
                <motion.a
                  key={link}
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  {link}
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </footer>
  );
}
