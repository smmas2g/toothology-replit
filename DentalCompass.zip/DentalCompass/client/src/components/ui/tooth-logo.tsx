import { cn } from "@/lib/utils";

interface ToothLogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  showText?: boolean;
}

export default function ToothLogo({ 
  size = "md", 
  className = "",
  showText = true 
}: ToothLogoProps) {
  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-10 h-10", 
    lg: "w-16 h-16",
    xl: "w-24 h-24"
  };

  const textSizeClasses = {
    sm: "text-sm",
    md: "text-xl",
    lg: "text-2xl", 
    xl: "text-4xl"
  };

  return (
    <div className={cn("flex items-center space-x-3", className)}>
      <div className={cn("relative", sizeClasses[size])}>
        <svg
          viewBox="0 0 100 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          {/* Tooth Crown - Main body with geometric pattern */}
          <path
            d="M20 30 L30 18 L40 22 L50 15 L60 18 L70 22 L80 30 L78 40 L75 50 L70 60 L65 70 L55 80 L50 85 L45 80 L35 70 L30 60 L25 50 L22 40 Z"
            fill="currentColor"
            className="text-white dark:text-gray-200"
            fillOpacity="0.95"
          />
          
          {/* Geometric wireframe structure - matching the attached image */}
          <g stroke="currentColor" strokeWidth="1.2" className="text-gray-600 dark:text-gray-400" fill="none">
            {/* Main triangular divisions */}
            <line x1="30" y1="25" x2="50" y2="45" />
            <line x1="70" y1="25" x2="50" y2="45" />
            <line x1="25" y1="45" x2="50" y2="65" />
            <line x1="75" y1="45" x2="50" y2="65" />
            <line x1="35" y1="65" x2="65" y2="65" />
            
            {/* Triangular segments creating geometric pattern */}
            <polygon points="35,25 50,40 45,50" />
            <polygon points="65,25 50,40 55,50" />
            <polygon points="30,45 45,60 35,70" />
            <polygon points="70,45 55,60 65,70" />
            
            {/* Central geometric elements */}
            <polygon points="45,35 55,35 50,45" />
            <polygon points="42,50 58,50 50,60" />
            
            {/* Connecting lines for geometric pattern */}
            <line x1="40" y1="30" x2="60" y2="30" />
            <line x1="38" y1="55" x2="62" y2="55" />
          </g>
          
          {/* Root structure - geometric wireframe style */}
          <path
            d="M45 80 L42 90 L44 100 L46 105 L48 110 L50 112 L52 110 L54 105 L56 100 L58 90 L55 80"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="text-gray-500 dark:text-gray-400"
          />
          
          {/* Root geometric pattern */}
          <g stroke="currentColor" strokeWidth="1" className="text-gray-500 dark:text-gray-400" fill="none">
            <line x1="45" y1="82" x2="50" y2="95" />
            <line x1="55" y1="82" x2="50" y2="95" />
            <line x1="47" y1="90" x2="53" y2="90" />
            <polygon points="49,95 51,95 50,105" />
          </g>
        </svg>
      </div>
      
      {showText && (
        <span className={cn("font-bold", textSizeClasses[size])}>
          Toothology Cheam Road
        </span>
      )}
    </div>
  );
}