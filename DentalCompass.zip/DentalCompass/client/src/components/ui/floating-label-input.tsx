import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useReducedMotion } from "@/hooks/use-scroll-animations";

interface FloatingLabelInputProps {
  label: string;
  type?: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  required?: boolean;
  multiline?: boolean;
  rows?: number;
  className?: string;
}

export const FloatingLabelInput = ({
  label,
  type = "text",
  value,
  onChange,
  error,
  required = false,
  multiline = false,
  rows = 4,
  className = ""
}: FloatingLabelInputProps) => {
  const [isFocused, setIsFocused] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);
  const shouldReduceMotion = useReducedMotion();

  const isFloating = isFocused || value.length > 0;

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
    validateInput();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
    
    if (error) {
      setIsValid(true);
    }
  };

  const validateInput = () => {
    if (required && value.length === 0) {
      setIsValid(false);
      return;
    }
    
    if (type === "email" && value.length > 0) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      setIsValid(emailRegex.test(value));
      return;
    }
    
    setIsValid(true);
  };

  const getBorderColor = () => {
    if (error || !isValid) return "border-red-500";
    if (isFocused) return "border-dental-dark";
    return "border-dental-beige";
  };

  const InputComponent = multiline ? Textarea : Input;

  return (
    <div className={`relative ${className}`}>
      {/* Input field */}
      <motion.div
        className="relative"
        initial={false}
        animate={{
          scale: isFocused && !shouldReduceMotion ? 1.01 : 1,
        }}
        transition={{ duration: 0.2 }}
      >
        <InputComponent
          ref={inputRef as any}
          type={type}
          value={value}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          rows={multiline ? rows : undefined}
          className={`
            w-full pt-6 pb-2 px-3 bg-white border-2 rounded-lg transition-all duration-300
            ${getBorderColor()}
            ${isFocused ? 'shadow-lg' : 'shadow-sm'}
            ${multiline ? 'resize-none' : ''}
            focus:outline-none focus:ring-0
          `}
          placeholder=""
        />

        {/* Floating label */}
        <motion.label
          className={`
            absolute left-3 pointer-events-none transition-all duration-300 cursor-text
            ${isFloating ? 'top-1 text-xs' : 'top-4 text-base'}
            ${isFocused ? 'text-dental-dark' : 'text-dental-grey'}
            ${error || !isValid ? 'text-red-500' : ''}
          `}
          animate={{
            y: isFloating && !shouldReduceMotion ? 0 : 0,
            scale: isFloating && !shouldReduceMotion ? 0.85 : 1,
          }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          onClick={() => inputRef.current?.focus()}
        >
          {label}
          {required && (
            <motion.span
              className="text-red-500 ml-1"
              initial={{ opacity: 0, scale: 0 }}
              animate={{ 
                opacity: isFloating || isFocused ? 1 : 0.7, 
                scale: 1 
              }}
              transition={{ duration: 0.2 }}
            >
              *
            </motion.span>
          )}
        </motion.label>

        {/* Focus underline effect */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-dental-dark"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: isFocused && !shouldReduceMotion ? 1 : 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          style={{ originX: 0.5 }}
        />
      </motion.div>

      {/* Error message */}
      <AnimatePresence>
        {(error || !isValid) && (
          <motion.div
            className="mt-2 text-red-500 text-sm flex items-center"
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 500 }}
              className="w-4 h-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center mr-2"
            >
              !
            </motion.div>
            {error || (required && value.length === 0 ? `${label} is required` : 
              type === "email" ? "Please enter a valid email address" : "Invalid input")}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success indicator */}
      <AnimatePresence>
        {value.length > 0 && isValid && !error && (
          <motion.div
            className="absolute right-3 top-4 w-5 h-5 rounded-full bg-green-500 text-white text-xs flex items-center justify-center"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 180 }}
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
          >
            ✓
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};