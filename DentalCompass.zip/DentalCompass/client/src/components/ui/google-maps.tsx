import { motion } from "framer-motion";

interface GoogleMapsProps {
  address?: string;
  className?: string;
}

export default function GoogleMaps({ 
  address = "125 Cheam Road, Sutton, SM1 2BH", 
  className = "" 
}: GoogleMapsProps) {
  // Create Google Maps URL with the address
  const mapsUrl = `https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${encodeURIComponent(address)}`;
  
  // Fallback to static map link
  const fallbackUrl = `https://www.google.com/maps?q=${encodeURIComponent(address)}`;

  return (
    <motion.div 
      className={`relative rounded-lg overflow-hidden shadow-lg ${className}`}
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
    >
      {/* Interactive Map Container */}
      <div className="aspect-video bg-gray-100 relative">
        {/* Placeholder map with click-to-open functionality */}
        <div className="absolute inset-0 bg-gradient-to-br from-dental-beige/20 to-dental-grey/20 flex items-center justify-center">
          <motion.a
            href={fallbackUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-center p-8 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg hover:bg-white transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="text-4xl mb-4">📍</div>
            <h3 className="font-semibold text-dental-dark mb-2">Toothology Cheam Road</h3>
            <p className="text-dental-text text-sm mb-4">{address}</p>
            <div className="inline-flex items-center space-x-2 text-dental-dark font-medium">
              <span>View on Google Maps</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </div>
          </motion.a>
        </div>
      </div>
      
      {/* Contact overlay */}
      <motion.div 
        className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-sm rounded-lg p-4 shadow-lg"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        viewport={{ once: true }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-dental-dark">Find Us</h4>
            <p className="text-sm text-dental-text">{address}</p>
          </div>
          <div className="text-right text-sm">
            <a 
              href="tel:02086429345" 
              className="block text-dental-dark font-medium hover:text-dental-grey transition-colors"
            >
              0208 642 9345
            </a>
            <a 
              href="mailto:admin@cheamdental.co.uk" 
              className="block text-dental-text hover:text-dental-dark transition-colors"
            >
              admin@cheamdental.co.uk
            </a>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}