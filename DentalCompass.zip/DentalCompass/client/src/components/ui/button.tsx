import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg font-medium ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 transform hover:scale-105 active:scale-95",
  {
    variants: {
      variant: {
        // Primary buttons - Clean blue/medical colors for main actions
        primary: "bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 shadow-lg hover:shadow-xl",
        
        // Call buttons - Green for phone actions
        call: "bg-gradient-to-r from-green-600 to-green-700 text-white hover:from-green-700 hover:to-green-800 shadow-lg hover:shadow-xl",
        
        // Emergency buttons - Red for urgent actions
        emergency: "bg-gradient-to-r from-red-600 to-red-700 text-white hover:from-red-700 hover:to-red-800 shadow-lg hover:shadow-xl",
        
        // Dental brand buttons - Using dental colors
        dental: "bg-gradient-to-r from-dental-dark to-dental-grey text-white hover:from-dental-grey hover:to-dental-dark shadow-lg hover:shadow-xl",
        
        // Secondary buttons - Clean white with border
        secondary: "bg-white border-2 border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white shadow-md hover:shadow-lg",
        
        // Outline buttons for less prominent actions
        outline: "border-2 border-current bg-transparent hover:bg-current hover:text-white transition-all duration-300",
        
        // Ghost buttons for subtle actions
        ghost: "hover:bg-dental-beige hover:text-dental-dark transition-all duration-300",
        
        // Link style for text-only buttons
        link: "text-dental-dark underline-offset-4 hover:underline hover:text-dental-grey transition-colors duration-300",
        
        // Tertiary buttons for navigation and footer
        tertiary: "text-dental-text hover:text-dental-dark transition-colors duration-300",
      },
      size: {
        sm: "h-9 px-3 text-sm rounded-md",
        default: "h-11 px-6 text-base rounded-lg",
        lg: "h-14 px-8 text-lg rounded-xl",
        xl: "h-16 px-10 text-xl rounded-xl",
        icon: "h-11 w-11 rounded-lg",
        "icon-sm": "h-9 w-9 rounded-md",
        "icon-lg": "h-14 w-14 rounded-xl",
        // Mobile-optimized sizes (min 44px touch target)
        mobile: "h-12 px-6 text-base rounded-lg min-h-[44px]",
        "mobile-lg": "h-14 px-8 text-lg rounded-xl min-h-[44px]",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
