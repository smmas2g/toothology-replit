import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Heart, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ToothLogo from "@/components/ui/tooth-logo";

const navigationItems = [
  { name: "Home", href: "/" },
  { name: "Services", href: "/services" },
  { name: "About", href: "/about" },
  { name: "Gallery", href: "/gallery" },
  { name: "Blog", href: "/blog" },
  { name: "Contact", href: "/contact" },
];

export default function Navigation() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm border-b border-dental-beige-light sticky top-0 z-50">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/">
            <ToothLogo size="md" className="cursor-pointer" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navigationItems.map((item) => (
              <Link key={item.name} href={item.href}>
                <span
                  className={`font-medium transition-colors cursor-pointer ${
                    location === item.href
                      ? "text-dental-dark"
                      : "text-dental-text hover:text-dental-dark"
                  }`}
                >
                  {item.name}
                </span>
              </Link>
            ))}
          </div>

          <div className="hidden lg:flex items-center space-x-3">
            <a href="tel:02086429345">
              <Button
                variant="call"
                size="default"
                className="hidden xl:flex"
              >
                <span className="mr-2">📞</span>
                Call: 0208 642 9345
              </Button>
            </a>
            <Link href="/patient-portal">
              <Button
                variant="secondary"
                size="default"
              >
                Patient Portal
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden min-h-[44px] min-w-[44px]">
                <Menu className="h-6 w-6 text-dental-dark" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:w-80">
              <div className="flex flex-col space-y-4 mt-8">
                {navigationItems.map((item) => (
                  <Link key={item.name} href={item.href}>
                    <span
                      className={`block px-4 py-3 font-medium transition-colors cursor-pointer min-h-[44px] rounded-lg flex items-center ${
                        location === item.href
                          ? "text-dental-dark bg-dental-beige"
                          : "text-dental-text hover:bg-dental-beige hover:text-dental-dark"
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.name}
                    </span>
                  </Link>
                ))}
                <div className="px-4 py-2">
                  <Link href="/patient-portal">
                    <Button
                      variant="secondary"
                      size="mobile"
                      className="w-full"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Patient Portal
                    </Button>
                  </Link>
                </div>
                
                {/* Mobile contact section */}
                <div className="border-t border-dental-beige pt-6 mt-6">
                  <div className="space-y-3 px-4">
                    <a 
                      href="tel:02086429345" 
                      className="flex items-center space-x-3 p-3 bg-dental-beige rounded-lg hover:bg-dental-beige-light transition-colors min-h-[44px]"
                    >
                      <span className="text-2xl">📞</span>
                      <div>
                        <div className="font-medium text-dental-dark text-base">Call Now</div>
                        <div className="text-sm text-dental-text">0208 642 9345</div>
                      </div>
                    </a>
                    <a 
                      href="mailto:admin@cheamdental.co.uk" 
                      className="flex items-center space-x-3 p-3 bg-dental-beige rounded-lg hover:bg-dental-beige-light transition-colors min-h-[44px]"
                    >
                      <span className="text-2xl">✉️</span>
                      <div>
                        <div className="font-medium text-dental-dark text-base">Email Us</div>
                        <div className="text-sm text-dental-text">admin@cheamdental.co.uk</div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
