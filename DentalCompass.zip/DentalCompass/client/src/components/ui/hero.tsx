import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative bg-gradient-to-br from-white via-dental-beige to-dental-beige-light min-h-screen flex items-center">
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-4xl lg:text-6xl font-bold text-dental-dark leading-tight"
              >
                Your Perfect{" "}
                <span className="text-dental-grey">Smile</span> Starts at Toothology
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="text-lg lg:text-xl text-dental-text leading-relaxed"
              >
                Experience exceptional dental care at Toothology Cheam Road with our modern approach,
                expert team, and state-of-the-art technology. We're committed to
                your oral health and beautiful smile.
              </motion.p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                size="lg"
                className="bg-dental-dark text-white hover:bg-dental-grey font-semibold px-8 py-4 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => scrollToSection('contact')}
              >
                Book Appointment
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-2 border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white font-semibold px-8 py-4 text-lg transition-all duration-300"
                onClick={() => scrollToSection('services')}
              >
                Learn More
              </Button>
            </motion.div>

            {/* Quick Info */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="grid grid-cols-3 gap-6 pt-8 border-t border-dental-beige-light"
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-dental-dark">15+</div>
                <div className="text-sm text-dental-grey">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-dental-dark">5000+</div>
                <div className="text-sm text-dental-grey">Happy Patients</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-dental-dark">10000+</div>
                <div className="text-sm text-dental-grey">Procedures</div>
              </div>
            </motion.div>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <img
              src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Modern dental office interior"
              className="rounded-2xl shadow-2xl w-full h-auto object-cover"
            />

            {/* Floating Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.2 }}
              className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-4 border border-dental-beige-light"
            >
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-dental-beige rounded-full flex items-center justify-center">
                  <span className="text-yellow-500 text-xl">⭐</span>
                </div>
                <div>
                  <div className="font-semibold text-dental-dark">4.9/5 Rating</div>
                  <div className="text-sm text-dental-grey">500+ Reviews</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
