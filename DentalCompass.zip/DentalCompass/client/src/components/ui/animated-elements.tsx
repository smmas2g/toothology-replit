import { motion, AnimatePresence, useScroll, useTransform } from "framer-motion";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { useStaggeredInView, useReducedMotion } from "@/hooks/use-scroll-animations";

// Animated button with ripple effect
export const AnimatedButton = ({ 
  children, 
  className = "", 
  onClick,
  variant = "default",
  ...props 
}: any) => {
  const [ripples, setRipples] = useState<Array<{ id: number; x: number; y: number }>>([]);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const shouldReduceMotion = useReducedMotion();

  const createRipple = (event: React.MouseEvent) => {
    if (!buttonRef.current || shouldReduceMotion) return;
    
    const rect = buttonRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    const newRipple = {
      id: Date.now(),
      x,
      y
    };
    
    setRipples(prev => [...prev, newRipple]);
    
    setTimeout(() => {
      setRipples(prev => prev.filter(ripple => ripple.id !== newRipple.id));
    }, 600);
    
    if (onClick) onClick(event);
  };

  return (
    <motion.div
      whileHover={{ scale: shouldReduceMotion ? 1 : 1.02 }}
      whileTap={{ scale: shouldReduceMotion ? 1 : 0.98 }}
      className="relative overflow-hidden rounded-lg"
    >
      <Button
        ref={buttonRef}
        className={`relative overflow-hidden ${className}`}
        onClick={createRipple}
        variant={variant}
        {...props}
      >
        {children}
        
        {/* Ripple effects */}
        <AnimatePresence>
          {ripples.map((ripple) => (
            <motion.div
              key={ripple.id}
              className="absolute bg-white/30 rounded-full pointer-events-none"
              style={{
                left: ripple.x - 10,
                top: ripple.y - 10,
              }}
              initial={{ width: 20, height: 20, opacity: 1 }}
              animate={{ 
                width: 200, 
                height: 200, 
                opacity: 0,
                x: -90,
                y: -90
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            />
          ))}
        </AnimatePresence>
      </Button>
    </motion.div>
  );
};

// Animated text reveal component
export const AnimatedTextReveal = ({ 
  text, 
  className = "",
  staggerDelay = 0.05 
}: { 
  text: string; 
  className?: string;
  staggerDelay?: number;
}) => {
  const { ref, isInView } = useStaggeredInView();
  const shouldReduceMotion = useReducedMotion();
  
  const words = text.split(" ");
  
  if (shouldReduceMotion) {
    return <div className={className}>{text}</div>;
  }

  return (
    <div ref={ref} className={className}>
      {words.map((word, wordIndex) => (
        <motion.span
          key={wordIndex}
          className="inline-block mr-2"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{
            duration: 0.6,
            delay: wordIndex * staggerDelay,
            ease: "easeOut"
          }}
        >
          {word.split("").map((char, charIndex) => (
            <motion.span
              key={charIndex}
              className="inline-block"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{
                duration: 0.4,
                delay: wordIndex * staggerDelay + charIndex * 0.02,
                ease: "easeOut"
              }}
            >
              {char}
            </motion.span>
          ))}
        </motion.span>
      ))}
    </div>
  );
};

// Staggered fade-in container
export const StaggeredFadeIn = ({ 
  children, 
  className = "",
  staggerDelay = 0.1 
}: { 
  children: React.ReactNode[]; 
  className?: string;
  staggerDelay?: number;
}) => {
  const { ref, isInView, getStaggerVariants } = useStaggeredInView(staggerDelay);
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <div ref={ref} className={className}>
      {children.map((child, index) => (
        <motion.div
          key={index}
          variants={getStaggerVariants(index)}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {child}
        </motion.div>
      ))}
    </div>
  );
};

// Animated image with hover effects
export const AnimatedImage = ({ 
  src, 
  alt, 
  className = "",
  overlayContent,
  ...props 
}: any) => {
  const [isHovered, setIsHovered] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      className={`relative overflow-hidden ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: shouldReduceMotion ? 1 : 1.02 }}
      transition={{ duration: 0.3 }}
    >
      <motion.img
        src={src}
        alt={alt}
        className="w-full h-full object-cover"
        animate={{ 
          scale: isHovered && !shouldReduceMotion ? 1.1 : 1,
          filter: isHovered && !shouldReduceMotion ? "brightness(0.8)" : "brightness(1)"
        }}
        transition={{ duration: 0.4 }}
        {...props}
      />
      
      {/* Overlay content */}
      <AnimatePresence>
        {isHovered && overlayContent && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center bg-black/40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              {overlayContent}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// Progress indicator
export const ScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-dental-dark to-dental-grey origin-left z-50"
      style={{ scaleX }}
    />
  );
};

// Simple loading display (no animation)
export const LoadingSpinner = ({ 
  size = "md", 
  className = "" 
}: { 
  size?: "sm" | "md" | "lg"; 
  className?: string; 
}) => {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-8 h-8",
    lg: "w-12 h-12"
  };

  return (
    <div className={`${sizeClasses[size]} border-2 border-dental-beige border-t-dental-dark rounded-full ${className}`}>
      <span className="sr-only">Loading...</span>
    </div>
  );
};

// Success/Error message with spring animation
export const AnimatedMessage = ({ 
  type, 
  message, 
  isVisible, 
  onClose 
}: {
  type: "success" | "error";
  message: string;
  isVisible: boolean;
  onClose: () => void;
}) => {
  const bgColor = type === "success" ? "bg-green-500" : "bg-red-500";
  
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className={`fixed top-4 right-4 ${bgColor} text-white px-6 py-3 rounded-lg shadow-lg z-50`}
          initial={{ opacity: 0, scale: 0.8, x: 100 }}
          animate={{ 
            opacity: 1, 
            scale: 1, 
            x: 0,
            y: [0, -5, 0]
          }}
          exit={{ opacity: 0, scale: 0.8, x: 100 }}
          transition={{ 
            type: "spring",
            stiffness: 500,
            damping: 30,
            y: {
              duration: 0.6,
              ease: "easeInOut"
            }
          }}
          onClick={onClose}
        >
          {message}
        </motion.div>
      )}
    </AnimatePresence>
  );
};