import { useState, useEffect, useRef } from "react";
import { motion, useAnimation, useInView, useScroll, useTransform } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  Smile, 
  Stethoscope, 
  Shield,
  Star,
  Phone,
  Calendar,
  Award,
  Users,
  Clock,
  CheckCircle
} from "lucide-react";

// Floating dental icons component
const FloatingIcons = () => {
  const icons = [
    { Icon: Heart, delay: 0, x: "10%", y: "20%" },
    { Icon: Smile, delay: 0.5, x: "85%", y: "15%" },
    { Icon: Stethoscope, delay: 1, x: "15%", y: "80%" },
    { Icon: Shield, delay: 1.5, x: "90%", y: "70%" },
    { Icon: Star, delay: 2, x: "50%", y: "10%" },
    { Icon: CheckCircle, delay: 2.5, x: "75%", y: "85%" }
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {icons.map(({ Icon, delay, x, y }, index) => (
        <motion.div
          key={index}
          className="absolute"
          style={{ left: x, top: y }}
          initial={{ opacity: 0, scale: 0, rotate: -180 }}
          animate={{ 
            opacity: 0.1, 
            scale: 1, 
            rotate: 0,
            y: [0, -20, 0],
            x: [0, 10, 0]
          }}
          transition={{
            delay,
            duration: 2,
            y: {
              repeat: Infinity,
              duration: 4 + index,
              ease: "easeInOut"
            },
            x: {
              repeat: Infinity,
              duration: 6 + index,
              ease: "easeInOut"
            }
          }}
        >
          <Icon className="w-8 h-8 md:w-12 md:h-12 text-dental-grey" />
        </motion.div>
      ))}
    </div>
  );
};

// Animated grid background
const AnimatedGrid = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-5">
      <motion.div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,0,0,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,0,0,0.1) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px"
        }}
        animate={{
          x: [0, 60],
          y: [0, 60]
        }}
        transition={{
          repeat: Infinity,
          duration: 20,
          ease: "linear"
        }}
      />
    </div>
  );
};

// Floating particles
const FloatingParticles = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const particles = Array.from({ length: 15 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 4 + 2,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute bg-dental-beige rounded-full opacity-20"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: particle.size,
            height: particle.size,
          }}
          animate={{
            x: mousePosition.x * 0.01,
            y: mousePosition.y * 0.01,
            scale: [1, 1.2, 1],
          }}
          transition={{
            x: { type: "spring", stiffness: 50 },
            y: { type: "spring", stiffness: 50 },
            scale: {
              repeat: Infinity,
              duration: 3 + particle.id * 0.5,
              ease: "easeInOut"
            }
          }}
        />
      ))}
    </div>
  );
};

// Typewriter effect hook
const useTypewriter = (text: string, speed: number = 100) => {
  const [displayText, setDisplayText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showCursor, setShowCursor] = useState(true);

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + text[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, speed);

      return () => clearTimeout(timeout);
    }
  }, [currentIndex, text, speed]);

  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 530);

    return () => clearInterval(cursorInterval);
  }, []);

  return { displayText, showCursor };
};

// Animated counter component
const AnimatedCounter = ({ 
  target, 
  prefix = "", 
  suffix = "", 
  duration = 2 
}: { 
  target: number; 
  prefix?: string; 
  suffix?: string; 
  duration?: number;
}) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let startTime: number;
      const animate = (currentTime: number) => {
        if (!startTime) startTime = currentTime;
        const progress = Math.min((currentTime - startTime) / (duration * 1000), 1);
        
        const easeOutCubic = 1 - Math.pow(1 - progress, 3);
        setCount(Math.floor(easeOutCubic * target));

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      requestAnimationFrame(animate);
    }
  }, [isInView, target, duration]);

  return (
    <span ref={ref}>
      {prefix}{count.toLocaleString()}{suffix}
    </span>
  );
};

// Magnetic button component
const MagneticButton = ({ children, className, ...props }: any) => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!buttonRef.current) return;
    
    const rect = buttonRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const deltaX = (e.clientX - centerX) * 0.15;
    const deltaY = (e.clientY - centerY) * 0.15;
    
    setMousePosition({ x: deltaX, y: deltaY });
  };

  return (
    <motion.div
      animate={{ x: mousePosition.x, y: mousePosition.y }}
      transition={{ type: "spring", stiffness: 400, damping: 40 }}
    >
      <Button
        ref={buttonRef}
        className={className}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => {
          setIsHovered(false);
          setMousePosition({ x: 0, y: 0 });
        }}
        {...props}
      >
        <motion.span
          animate={{ scale: isHovered ? 1.05 : 1 }}
          transition={{ type: "spring", stiffness: 400 }}
        >
          {children}
        </motion.span>
      </Button>
    </motion.div>
  );
};

export default function AdvancedHero() {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 300], [0, -50]);
  const y2 = useTransform(scrollY, [0, 300], [0, -100]);
  
  const { displayText: titleText, showCursor } = useTypewriter(
    "Your Perfect Smile Starts at Toothology", 
    80
  );

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated gradient background */}
      <motion.div 
        className="absolute inset-0"
        animate={{
          background: [
            "linear-gradient(135deg, #ffffff 0%, #f8f6f3 50%, #f0ebe4 100%)",
            "linear-gradient(135deg, #f8f6f3 0%, #f0ebe4 50%, #e8e0d6 100%)",
            "linear-gradient(135deg, #f0ebe4 0%, #e8e0d6 50%, #ffffff 100%)",
            "linear-gradient(135deg, #ffffff 0%, #f8f6f3 50%, #f0ebe4 100%)"
          ]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Background elements */}
      <AnimatedGrid />
      <FloatingParticles />
      <FloatingIcons />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <motion.div 
            className="text-center lg:text-left space-y-8"
            style={{ y: y1 }}
          >
            {/* Logo with breathing effect */}
            <motion.div
              className="w-20 h-20 mx-auto lg:mx-0 mb-8 bg-gradient-to-br from-dental-beige to-dental-beige-light rounded-full flex items-center justify-center"
              animate={{ 
                scale: [1, 1.1, 1],
                boxShadow: [
                  "0 0 0 0 rgba(240, 235, 228, 0.4)",
                  "0 0 0 20px rgba(240, 235, 228, 0)",
                  "0 0 0 0 rgba(240, 235, 228, 0)"
                ]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Heart className="h-10 w-10 text-dental-dark" />
            </motion.div>

            {/* Typewriter title */}
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-dental-dark leading-tight min-h-[120px] lg:min-h-[140px]">
                {titleText}
                <motion.span
                  animate={{ opacity: showCursor ? 1 : 0 }}
                  className="text-dental-grey"
                >
                  |
                </motion.span>
              </h1>

              {/* Staggered subtitle */}
              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 3 }}
                className="text-lg lg:text-xl text-dental-text leading-relaxed"
              >
                Experience exceptional dental care with our modern approach,
                expert team, and state-of-the-art technology.
              </motion.p>
            </div>

            {/* CTA Buttons with magnetic effect */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 3.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <MagneticButton
                size="lg"
                className="bg-dental-dark hover:bg-dental-dark/90 text-white px-8 py-4 text-lg"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Book Appointment
              </MagneticButton>

              {/* Emergency button with pulse effect */}
              <motion.div
                animate={{ 
                  scale: [1, 1.05, 1],
                  boxShadow: [
                    "0 0 0 0 rgba(239, 68, 68, 0.4)",
                    "0 0 0 15px rgba(239, 68, 68, 0)",
                    "0 0 0 0 rgba(239, 68, 68, 0)"
                  ]
                }}
                transition={{ 
                  duration: 2, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <MagneticButton
                  variant="outline"
                  size="lg"
                  className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-4 text-lg"
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Emergency Call
                </MagneticButton>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Hero Image with parallax */}
          <motion.div 
            className="relative"
            style={{ y: y2 }}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative z-10">
              <motion.img
                src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                alt="Modern dental practice"
                className="w-full h-auto rounded-2xl shadow-2xl"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dental-dark/20 to-transparent rounded-2xl"></div>
            </div>
            <div className="absolute -top-4 -right-4 w-full h-full bg-gradient-to-br from-dental-beige to-dental-beige-light rounded-2xl -z-10"></div>

            {/* Floating rating card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.2 }}
              className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-4 border border-dental-beige-light"
              whileHover={{ scale: 1.05, y: -5 }}
            >
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-dental-beige rounded-full flex items-center justify-center">
                  <Star className="text-yellow-500 h-6 w-6 fill-current" />
                </div>
                <div>
                  <div className="font-semibold text-dental-dark">
                    <AnimatedCounter target={4.9} suffix="/5" /> Rating
                  </div>
                  <div className="text-sm text-dental-grey">
                    <AnimatedCounter target={500} suffix="+" /> Reviews
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Trust indicators section */}
      <motion.div 
        className="absolute bottom-0 left-0 right-0 bg-white/80 backdrop-blur-sm border-t border-dental-beige py-8"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 4 }}
      >
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-center mb-2">
                <Users className="h-8 w-8 text-dental-dark" />
              </div>
              <div className="text-2xl lg:text-3xl font-bold text-dental-dark">
                <AnimatedCounter target={10000} suffix="+" />
              </div>
              <div className="text-sm text-dental-text">Happy Patients</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-center mb-2">
                <Award className="h-8 w-8 text-dental-dark" />
              </div>
              <div className="text-2xl lg:text-3xl font-bold text-dental-dark">
                <AnimatedCounter target={15} suffix="+" />
              </div>
              <div className="text-sm text-dental-text">Years Experience</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-center mb-2">
                <Star className="h-8 w-8 text-dental-dark fill-current" />
              </div>
              <div className="text-2xl lg:text-3xl font-bold text-dental-dark">
                <AnimatedCounter target={5} suffix="-Star" />
              </div>
              <div className="text-sm text-dental-text">Average Rating</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-center mb-2">
                <Clock className="h-8 w-8 text-dental-dark" />
              </div>
              <div className="text-2xl lg:text-3xl font-bold text-dental-dark">24/7</div>
              <div className="text-sm text-dental-text">Emergency Care</div>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}