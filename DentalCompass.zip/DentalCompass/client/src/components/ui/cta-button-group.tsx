import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface CTAButtonGroupProps {
  variant?: "default" | "stacked" | "inline";
  showEmergency?: boolean;
  className?: string;
}

export default function CTAButtonGroup({ 
  variant = "default", 
  showEmergency = false,
  className = ""
}: CTAButtonGroupProps) {
  const buttonLayout = variant === "stacked" ? "flex-col" : "flex-row";
  const gapSize = variant === "stacked" ? "gap-3" : "gap-4";

  return (
    <div className={`flex ${buttonLayout} ${gapSize} justify-center items-center ${className}`}>
      {/* Primary CTA - Book Appointment */}
      <Link href="/contact">
        <Button 
          variant="primary"
          size="mobile-lg"
          className="w-full sm:w-auto"
        >
          <span className="mr-2">📅</span>
          Book Appointment
        </Button>
      </Link>

      {/* Secondary CTA - Call */}
      <a href="tel:02086429345">
        <Button 
          variant="call"
          size="mobile-lg"
          className="w-full sm:w-auto"
        >
          <span className="mr-2">📞</span>
          Call: 0208 642 9345
        </Button>
      </a>

      {/* Emergency CTA - Only show when requested */}
      {showEmergency && (
        <a href="tel:02086429345">
          <Button 
            variant="emergency"
            size="mobile-lg"
            className="w-full sm:w-auto"
          >
            <span className="mr-2">🚨</span>
            Emergency
          </Button>
        </a>
      )}
    </div>
  );
}

// Component for consistent "Learn More" buttons
export function LearnMoreButton({ 
  href, 
  children = "Learn More",
  size = "default"
}: { 
  href: string; 
  children?: React.ReactNode;
  size?: "sm" | "default" | "lg";
}) {
  return (
    <Link href={href}>
      <Button 
        variant="secondary"
        size={size}
        className="group"
      >
        {children}
        <motion.span
          className="ml-2 transition-transform group-hover:translate-x-1"
          initial={{ x: 0 }}
          whileHover={{ x: 4 }}
        >
          →
        </motion.span>
      </Button>
    </Link>
  );
}

// Component for navigation buttons
export function NavigationButton({ 
  href, 
  children, 
  isActive = false 
}: { 
  href: string; 
  children: React.ReactNode;
  isActive?: boolean;
}) {
  return (
    <Link href={href}>
      <Button 
        variant={isActive ? "dental" : "ghost"}
        size="default"
        className="justify-start"
      >
        {children}
      </Button>
    </Link>
  );
}