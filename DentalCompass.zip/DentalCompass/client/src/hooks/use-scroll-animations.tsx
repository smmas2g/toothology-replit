import { useEffect, useState, useRef } from "react";
import { useScroll, useTransform, useSpring, useInView } from "framer-motion";

// Hook for scroll progress
export const useScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });
  
  return scaleX;
};

// Hook for parallax effects
export const useParallax = (offset = 50) => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 1000], [0, offset]);
  
  return y;
};

// Hook for staggered animations
export const useStaggeredInView = (staggerDelay = 0.1) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  
  const getStaggerVariants = (index: number) => ({
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.95
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        delay: index * staggerDelay,
        ease: "easeOut"
      }
    }
  });
  
  return { ref, isInView, getStaggerVariants };
};

// Hook for text reveal animations
export const useTextReveal = (text: string, triggerInView = true) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [revealedText, setRevealedText] = useState("");
  
  useEffect(() => {
    if (!triggerInView || isInView) {
      let currentIndex = 0;
      const interval = setInterval(() => {
        if (currentIndex <= text.length) {
          setRevealedText(text.slice(0, currentIndex));
          currentIndex++;
        } else {
          clearInterval(interval);
        }
      }, 50);
      
      return () => clearInterval(interval);
    }
  }, [isInView, text, triggerInView]);
  
  return { ref, revealedText, isComplete: revealedText.length === text.length };
};

// Hook for reduced motion detection
export const useReducedMotion = () => {
  const [shouldReduceMotion, setShouldReduceMotion] = useState(false);
  
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setShouldReduceMotion(mediaQuery.matches);
    
    const handleChange = (event: MediaQueryListEvent) => {
      setShouldReduceMotion(event.matches);
    };
    
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);
  
  return shouldReduceMotion;
};

// Hook for intersection observer with threshold
export const useIntersectionObserver = (
  threshold = 0.1,
  rootMargin = "0px"
) => {
  const ref = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
      },
      { threshold, rootMargin }
    );
    
    if (ref.current) {
      observer.observe(ref.current);
    }
    
    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [threshold, rootMargin]);
  
  return { ref, isVisible };
};