import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import AdvancedHero from "@/components/ui/advanced-hero";
import InteractiveServiceCards from "@/components/ui/interactive-service-cards";
import { ScrollProgress, StaggeredFadeIn, AnimatedTextReveal, AnimatedImage } from "@/components/ui/animated-elements";
import { useParallax, useStaggeredInView } from "@/hooks/use-scroll-animations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { 
  Heart, 
  Smile, 
  User, 
  Stethoscope, 
  Shield,
  ArrowRight,
  Star,
  Phone,
  Mail,
  MapPin,
  Clock,
  Award,
  Users,
  Calendar,
  PlayCircle,
  ChevronLeft,
  ChevronRight,
  Filter,
  X,
  CheckCircle,
  Microscope
} from "lucide-react";
import type { Service, Testimonial, GalleryImage, TeamMember } from "@shared/schema";
import MobileBottomBar from "@/components/ui/mobile-bottom-bar";

const serviceData = [
  {
    title: "Invisalign",
    description: "Invisible orthodontic treatment for a perfect smile without traditional braces.",
    icon: Smile,
    slug: "invisalign",
    color: "from-blue-500 to-blue-600"
  },
  {
    title: "Dental Implants", 
    description: "Permanent tooth replacement solution that looks and feels like natural teeth.",
    icon: Shield,
    slug: "dental-implants",
    color: "from-green-500 to-green-600"
  },
  {
    title: "Cosmetic Dentistry",
    description: "Transform your smile with veneers, whitening, and aesthetic treatments.",
    icon: Star,
    slug: "cosmetic-dentistry", 
    color: "from-purple-500 to-purple-600"
  },
  {
    title: "Periodontics",
    description: "Specialized treatment for gum disease and maintaining healthy gums.",
    icon: Heart,
    slug: "periodontics",
    color: "from-red-500 to-red-600"
  },
  {
    title: "Root Canal",
    description: "Pain-free root canal therapy to save infected or damaged teeth.",
    icon: Stethoscope,
    slug: "root-canal",
    color: "from-orange-500 to-orange-600"
  },
  {
    title: "Dental Hygienist",
    description: "Professional cleanings and preventive care for optimal oral health.",
    icon: CheckCircle,
    slug: "dental-hygienist",
    color: "from-teal-500 to-teal-600"
  }
];

export default function Home() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [galleryFilter, setGalleryFilter] = useState("All");
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const { data: services, isLoading: servicesLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const { data: testimonials, isLoading: testimonialsLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials/featured"],
  });

  const { data: galleryImages, isLoading: galleryLoading } = useQuery<GalleryImage[]>({
    queryKey: ["/api/gallery/featured"],
  });

  const { data: teamMembers, isLoading: teamLoading } = useQuery<TeamMember[]>({
    queryKey: ["/api/team"],
  });

  const filteredGallery = galleryImages?.filter(image => 
    galleryFilter === "All" || image.category === galleryFilter
  ) || [];

  const nextTestimonial = () => {
    if (testimonials && testimonials.length > 0) {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }
  };

  const prevTestimonial = () => {
    if (testimonials && testimonials.length > 0) {
      setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    }
  };

  const parallaxY = useParallax(-50);

  return (
    <div className="min-h-screen bg-white">
      <ScrollProgress />
      <Navigation />
      
      {/* ADVANCED HERO SECTION */}
      <AdvancedHero />

      {/* INTERACTIVE SERVICES SECTION */}
      <InteractiveServiceCards />

      {/* ABOUT SECTION */}
      <section className="py-16 lg:py-24 bg-gradient-to-br from-dental-beige/30 to-white relative overflow-hidden">
        {/* Parallax background elements */}
        <motion.div 
          className="absolute inset-0 opacity-5"
          style={{ y: parallaxY }}
        >
          <div className="absolute top-20 left-10 w-32 h-32 bg-dental-grey rounded-full blur-xl"></div>
          <div className="absolute bottom-20 right-10 w-48 h-48 bg-dental-beige rounded-full blur-2xl"></div>
        </motion.div>
        
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <AnimatedTextReveal 
                text="About Toothology Cheam Road"
                className="text-2xl md:text-3xl lg:text-5xl font-bold text-dental-dark mb-6 md:mb-8"
              />
              <div className="space-y-4 md:space-y-6">
                <p className="text-base md:text-lg text-dental-text leading-relaxed">
                  Toothology Cheam Road has been at the forefront of modern dentistry, 
                  combining state-of-the-art technology with compassionate, patient-centered care. 
                  Our mission is simple: to help you achieve and maintain optimal oral health while 
                  creating the beautiful smile you deserve.
                </p>
                <p className="text-dental-text leading-relaxed">
                  We believe that every patient is unique, which is why we take the time to understand 
                  your individual needs, concerns, and goals. Our comprehensive approach ensures that 
                  you receive personalized treatment plans designed specifically for you.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mt-6 md:mt-8">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-dental-dark rounded-full flex items-center justify-center">
                    <Microscope className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-dental-dark">Advanced Technology</h4>
                    <p className="text-sm text-dental-text">Latest equipment & techniques</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-dental-dark rounded-full flex items-center justify-center">
                    <Heart className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-dental-dark">Patient-Centered Care</h4>
                    <p className="text-sm text-dental-text">Comfort & satisfaction first</p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              {/* Team Showcase with staggered animations */}
              {teamLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="bg-dental-beige rounded-2xl p-6">
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 bg-dental-beige-light rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-dental-beige-light rounded mb-2"></div>
                          <div className="h-3 bg-dental-beige-light rounded w-3/4"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <StaggeredFadeIn className="space-y-4">
                  {teamMembers?.slice(0, 3).map((member, index) => (
                    <motion.div
                      key={member.id}
                      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300"
                      whileHover={{ scale: 1.02, y: -5 }}
                    >
                      <div className="flex items-center space-x-4">
                        <AnimatedImage
                          src={member.imageUrl}
                          alt={member.name}
                          className="w-16 h-16 rounded-full overflow-hidden"
                          overlayContent={
                            <div className="text-white text-center">
                              <div className="text-sm font-medium">View Profile</div>
                            </div>
                          }
                        />
                        <div>
                          <h4 className="font-semibold text-dental-dark">{member.name}</h4>
                          <p className="text-dental-text text-sm">{member.position}</p>
                          <p className="text-dental-grey text-xs">{member.experience}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </StaggeredFadeIn>
              )}

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
                className="bg-dental-dark rounded-2xl p-8 text-white"
              >
                <h4 className="font-bold text-xl mb-4">Our Philosophy</h4>
                <p className="text-gray-200 leading-relaxed">
                  "We believe that exceptional dental care goes beyond just treating teeth. 
                  It's about building lasting relationships, understanding individual needs, 
                  and providing a comfortable, stress-free experience for every patient."
                </p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* SMILE STUDIO GALLERY */}
      <section className="py-12 md:py-16 lg:py-24 bg-white relative overflow-hidden">
        {/* Parallax elements */}
        <motion.div 
          className="absolute inset-0 opacity-3"
          style={{ y: useParallax(30) }}
        >
          <div className="absolute top-32 right-20 w-64 h-64 bg-gradient-to-br from-dental-beige to-dental-grey rounded-full blur-3xl"></div>
        </motion.div>
        
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <AnimatedTextReveal 
              text="Smile Studio Gallery"
              className="text-2xl md:text-3xl lg:text-5xl font-bold text-dental-dark mb-4 md:mb-6"
            />
            <p className="text-base md:text-lg text-dental-text max-w-3xl mx-auto leading-relaxed mb-6 md:mb-8">
              See the incredible transformations we've achieved for our patients. 
              Every smile tells a story of renewed confidence and improved oral health.
            </p>

            {/* Gallery Filter */}
            <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-8 md:mb-12">
              {["All", "Cosmetic Dentistry", "Orthodontics", "Dental Implants"].map((filter) => (
                <Button
                  key={filter}
                  variant={galleryFilter === filter ? "dental" : "secondary"}
                  size="mobile"
                  onClick={() => setGalleryFilter(filter)}
                  className="text-sm md:text-base"
                >
                  <Filter className="mr-2 h-4 w-4" />
                  {filter}
                </Button>
              ))}
            </div>
          </motion.div>

          {/* Gallery Grid with staggered animations */}
          {galleryLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-dental-beige rounded-2xl aspect-square"></div>
              ))}
            </div>
          ) : (
            <StaggeredFadeIn className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8" staggerDelay={0.15}>
              {filteredGallery.map((image, index) => (
                <motion.div
                  key={image.id}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="group cursor-pointer"
                  onClick={() => setSelectedImage(image)}
                >
                  <AnimatedImage
                    src={image.imageUrl}
                    alt={image.title}
                    className="aspect-square rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300"
                    overlayContent={
                      <div className="text-white text-center p-6">
                        <h3 className="font-semibold text-lg mb-2">{image.title}</h3>
                        <p className="text-sm opacity-90 mb-4">{image.description}</p>
                        <Badge className="bg-white/20 text-white border-white/30">
                          {image.category}
                        </Badge>
                        <div className="mt-4">
                          <PlayCircle className="h-6 w-6 mx-auto" />
                        </div>
                      </div>
                    }
                  />
                </motion.div>
              ))}
            </StaggeredFadeIn>
          )}

          {/* Lightbox Modal */}
          <AnimatePresence>
            {selectedImage && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
                onClick={() => setSelectedImage(null)}
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.9, opacity: 0 }}
                  className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="relative">
                    <img
                      src={selectedImage.imageUrl}
                      alt={selectedImage.title}
                      className="w-full h-auto max-h-[70vh] object-cover"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-4 right-4 bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white"
                      onClick={() => setSelectedImage(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="p-6">
                    <h3 className="text-2xl font-bold text-dental-dark mb-2">{selectedImage.title}</h3>
                    <p className="text-dental-text mb-4">{selectedImage.description}</p>
                    <Badge className="bg-dental-beige text-dental-dark">
                      {selectedImage.category}
                    </Badge>
                    <p className="text-xs text-dental-grey mt-4">
                      * All images used with patient consent and comply with privacy regulations
                    </p>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-12 md:py-16 lg:py-24 bg-gradient-to-br from-dental-beige/30 to-white relative overflow-hidden">
        {/* Parallax background */}
        <motion.div 
          className="absolute inset-0 opacity-5"
          style={{ y: useParallax(-30) }}
        >
          <div className="absolute top-40 left-32 w-96 h-96 bg-dental-grey rounded-full blur-3xl"></div>
        </motion.div>
        
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <AnimatedTextReveal 
              text="What Our Patients Say"
              className="text-2xl md:text-3xl lg:text-5xl font-bold text-dental-dark mb-4 md:mb-6"
            />
            <p className="text-base md:text-lg text-dental-text max-w-3xl mx-auto leading-relaxed">
              Don't just take our word for it. Here's what our satisfied patients have to say 
              about their experience at Toothology Cheam Road.
            </p>
          </motion.div>

          {testimonialsLoading ? (
            <div className="max-w-4xl mx-auto">
              <div className="bg-dental-beige rounded-2xl p-8 animate-pulse">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-dental-beige-light rounded-full mr-4"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-dental-beige-light rounded mb-2"></div>
                    <div className="h-3 bg-dental-beige-light rounded w-1/2"></div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="h-4 bg-dental-beige-light rounded"></div>
                  <div className="h-4 bg-dental-beige-light rounded w-3/4"></div>
                </div>
              </div>
            </div>
          ) : testimonials && testimonials.length > 0 ? (
            <div className="max-w-4xl mx-auto relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentTestimonial}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-2xl shadow-xl p-8 lg:p-12"
                >
                  <div className="flex items-center mb-8">
                    <div className="w-16 h-16 bg-dental-beige rounded-full flex items-center justify-center mr-6">
                      <User className="h-8 w-8 text-dental-dark" />
                    </div>
                    <div>
                      <h4 className="font-bold text-dental-dark text-xl">
                        {testimonials[currentTestimonial].patientName}
                      </h4>
                      <p className="text-dental-text">{testimonials[currentTestimonial].treatment}</p>
                      <div className="flex items-center mt-2">
                        {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                        ))}
                      </div>
                    </div>
                  </div>
                  <blockquote className="text-lg lg:text-xl text-dental-text leading-relaxed italic">
                    "{testimonials[currentTestimonial].content}"
                  </blockquote>
                </motion.div>
              </AnimatePresence>

              {/* Navigation with micro-interactions */}
              <div className="flex justify-center items-center mt-8 space-x-4">
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Button
                    variant="secondary"
                    size="icon"
                    onClick={prevTestimonial}
                  >
                    <motion.div
                      animate={{ x: [-2, 2, -2] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </motion.div>
                  </Button>
                </motion.div>
                <div className="flex space-x-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      className={`w-4 h-4 rounded-full transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${
                        index === currentTestimonial ? "bg-dental-dark" : "bg-dental-beige hover:bg-dental-grey"
                      }`}
                      onClick={() => setCurrentTestimonial(index)}
                      aria-label={`Go to testimonial ${index + 1}`}
                    >
                      <span className={`w-3 h-3 rounded-full ${
                        index === currentTestimonial ? "bg-white" : "bg-dental-dark"
                      }`} />
                    </button>
                  ))}
                </div>
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Button
                    variant="secondary"
                    size="icon"
                    onClick={nextTestimonial}
                  >
                    <motion.div
                      animate={{ x: [2, -2, 2] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </motion.div>
                  </Button>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
                className="text-center mt-12"
              >
                <p className="text-dental-text mb-4">
                  Join thousands of satisfied patients who trust Toothology Cheam Road
                </p>
                <div className="flex justify-center items-center space-x-8">
                  <div className="flex items-center space-x-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <span className="font-semibold text-dental-dark">4.9/5</span>
                  </div>
                  <div className="text-dental-text">
                    <span className="font-semibold">500+</span> Google Reviews
                  </div>
                </div>
              </motion.div>
            </div>
          ) : null}
        </div>
      </section>

      {/* CONTACT SECTION */}
      <section className="py-16 lg:py-24 bg-dental-dark text-white relative overflow-hidden">
        {/* Animated background elements */}
        <motion.div 
          className="absolute inset-0 opacity-10"
          style={{ y: useParallax(40) }}
        >
          <div className="absolute top-20 right-10 w-72 h-72 bg-dental-beige rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 left-20 w-48 h-48 bg-white rounded-full blur-2xl"></div>
        </motion.div>
        
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12 md:mb-16"
          >
            <AnimatedTextReveal 
              text="Ready to Transform Your Smile?"
              className="text-2xl md:text-3xl lg:text-5xl font-bold mb-4 md:mb-6"
            />
            <p className="text-base md:text-lg text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Contact us today to schedule your consultation. We're here to help you achieve 
              the healthy, beautiful smile you've always wanted.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 md:gap-16">
            {/* Contact Information with staggered animations */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div>
                <h3 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Get in Touch</h3>
                <StaggeredFadeIn className="space-y-4 md:space-y-6">
                  {[
                    { icon: MapPin, title: "Main Location", content: "125 Cheam Road, Sutton, SM1 2BH", color: "bg-dental-beige" },
                    { icon: Phone, title: "Phone", content: "0208 642 9345", color: "bg-dental-beige", href: "tel:02086429345" },
                    { icon: Mail, title: "Email", content: "admin@cheamdental.co.uk", color: "bg-dental-beige", href: "mailto:admin@cheamdental.co.uk" },
                    { icon: Phone, title: "Emergency Line", content: "0208 642 9345 - Available 24/7", color: "bg-red-500", textColor: "text-red-300", href: "tel:02086429345" }
                  ].map((item, index) => (
                    <motion.div 
                      key={index}
                      className="flex items-center space-x-4"
                      whileHover={{ x: 10, transition: { duration: 0.2 } }}
                    >
                      <motion.div 
                        className={`w-12 h-12 min-w-[48px] ${item.color} rounded-full flex items-center justify-center`}
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        transition={{ duration: 0.3 }}
                      >
                        <item.icon className={`h-6 w-6 ${item.color === "bg-red-500" ? "text-white" : "text-dental-dark"}`} />
                      </motion.div>
                      <div>
                        <h4 className={`font-semibold text-base ${item.textColor || ""}`}>{item.title}</h4>
                        {item.href ? (
                          <a href={item.href} className="text-gray-300 hover:text-white transition-colors text-sm md:text-base">
                            {item.content}
                          </a>
                        ) : (
                          <p className="text-gray-300 text-sm md:text-base">{item.content}</p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </StaggeredFadeIn>
              </div>

              <div>
                <h4 className="font-semibold text-xl mb-4">Office Hours</h4>
                <div className="space-y-2 text-gray-300">
                  <div className="flex justify-between">
                    <span>Monday - Friday</span>
                    <span>9:00 - 18:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Saturday</span>
                    <span>9:00 - 13:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday</span>
                    <span>Closed</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Quick Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Quick Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-white text-sm font-medium mb-2 block">
                        First Name
                      </label>
                      <input 
                        type="text"
                        className="w-full p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-dental-beige"
                        placeholder="John"
                      />
                    </div>
                    <div>
                      <label className="text-white text-sm font-medium mb-2 block">
                        Last Name
                      </label>
                      <input 
                        type="text"
                        className="w-full p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-dental-beige"
                        placeholder="Doe"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Email
                    </label>
                    <input 
                      type="email"
                      className="w-full p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-dental-beige"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Phone
                    </label>
                    <input 
                      type="tel"
                      className="w-full p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-dental-beige"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Service Interest
                    </label>
                    <select className="w-full p-3 rounded-lg bg-white/10 border border-white/20 text-white focus:outline-none focus:ring-2 focus:ring-dental-beige">
                      <option value="">Select a service</option>
                      <option value="general">General Dentistry</option>
                      <option value="cosmetic">Cosmetic Dentistry</option>
                      <option value="orthodontics">Orthodontics</option>
                      <option value="implants">Dental Implants</option>
                      <option value="emergency">Emergency Care</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-white text-sm font-medium mb-2 block">
                      Message
                    </label>
                    <textarea 
                      rows={4}
                      className="w-full p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-dental-beige resize-none"
                      placeholder="Tell us about your dental needs..."
                    />
                  </div>
                  <Button 
                    variant="primary" 
                    size="mobile-lg" 
                    className="w-full"
                  >
                    <Calendar className="mr-2 h-5 w-5" />
                    Schedule Consultation
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
      <MobileBottomBar />
    </div>
  );
}