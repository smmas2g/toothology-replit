import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useState } from "react";
import { X, ZoomIn } from "lucide-react";
import type { GalleryImage } from "@shared/schema";

const categories = ["All", "Cosmetic Dentistry", "Orthodontics", "Facility", "Before & After"];

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const { data: galleryImages, isLoading } = useQuery<GalleryImage[]>({
    queryKey: ["/api/gallery"],
  });

  const filteredImages = galleryImages?.filter(image => 
    selectedCategory === "All" || image.category === selectedCategory
  ) || [];

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-white via-dental-beige to-dental-beige-light py-16 lg:py-24">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-dental-dark mb-6">
              Smile <span className="text-dental-grey">Gallery</span>
            </h1>
            <p className="text-lg lg:text-xl text-dental-text leading-relaxed">
              Discover the beautiful transformations we've achieved for our patients. 
              Each smile tells a story of confidence, health, and happiness.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Categories */}
      <section className="py-8 bg-white border-b border-dental-beige-light">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-wrap justify-center gap-3"
          >
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className={`${
                  selectedCategory === category
                    ? "bg-dental-dark text-white hover:bg-dental-grey"
                    : "border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white"
                } transition-all duration-300`}
              >
                {category}
              </Button>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(12)].map((_, i) => (
                <div key={i} className="rounded-xl shadow-lg w-full h-64 bg-dental-beige animate-pulse"></div>
              ))}
            </div>
          ) : filteredImages.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center py-16"
            >
              <div className="w-24 h-24 bg-dental-beige rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-dental-dark text-3xl">📷</span>
              </div>
              <h3 className="text-2xl font-semibold text-dental-dark mb-4">
                No Images Found
              </h3>
              <p className="text-dental-text">
                {selectedCategory === "All" 
                  ? "We're updating our gallery. Please check back soon!"
                  : `No images found in the ${selectedCategory} category. Try selecting a different category.`
                }
              </p>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {filteredImages.map((image, index) => (
                <motion.div
                  key={image.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: index * 0.05 }}
                  className="group cursor-pointer"
                >
                  <Dialog>
                    <DialogTrigger asChild>
                      <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
                        <div className="relative">
                          <img
                            src={image.imageUrl}
                            alt={image.title}
                            className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                            <ZoomIn className="text-white h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                          </div>
                          <Badge className="absolute top-3 left-3 bg-white text-dental-dark">
                            {image.category}
                          </Badge>
                        </div>
                        <CardContent className="p-4">
                          <h3 className="font-semibold text-dental-dark mb-2">
                            {image.title}
                          </h3>
                          {image.description && (
                            <p className="text-sm text-dental-text line-clamp-2">
                              {image.description}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl w-full p-0">
                      <div className="relative">
                        <img
                          src={image.imageUrl}
                          alt={image.title}
                          className="w-full h-auto max-h-[80vh] object-contain"
                        />
                        <div className="p-6">
                          <div className="flex items-center justify-between mb-4">
                            <h3 className="text-2xl font-semibold text-dental-dark">
                              {image.title}
                            </h3>
                            <Badge variant="secondary">{image.category}</Badge>
                          </div>
                          {image.description && (
                            <p className="text-dental-text leading-relaxed">
                              {image.description}
                            </p>
                          )}
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-24 bg-dental-beige">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-6">
              Ready for Your Smile Transformation?
            </h2>
            <p className="text-lg text-dental-text mb-8 leading-relaxed">
              Join the thousands of patients who have transformed their smiles with us. 
              Schedule your consultation today and start your journey to a healthier, more confident you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-dental-dark text-white hover:bg-dental-grey px-8 py-4 text-lg"
                onClick={() => {
                  const element = document.getElementById('contact');
                  if (element) element.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Book Consultation
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-2 border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white px-8 py-4 text-lg"
                onClick={() => window.location.href = '/services'}
              >
                View Services
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
