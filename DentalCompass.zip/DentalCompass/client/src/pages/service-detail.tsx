import { useParams } from "wouter";
import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { 
  Heart, 
  Smile, 
  User, 
  Stethoscope, 
  Baby, 
  Ambulance,
  ArrowLeft,
  CheckCircle,
  Phone
} from "lucide-react";
import type { Service } from "@shared/schema";

const serviceIcons = {
  "fas fa-tooth": Heart,
  "fas fa-smile": Smile,
  "fas fa-grip-lines": User,
  "fas fa-user-md": Stethoscope,
  "fas fa-child": Baby,
  "fas fa-ambulance": Ambulance,
};

export default function ServiceDetail() {
  const { slug } = useParams();
  
  const { data: service, isLoading, error } = useQuery<Service>({
    queryKey: ["/api/services", slug],
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="container mx-auto px-4 lg:px-8 py-16">
          <div className="animate-pulse">
            <div className="h-12 bg-dental-beige rounded mb-6 w-3/4"></div>
            <div className="h-6 bg-dental-beige rounded mb-4 w-1/2"></div>
            <div className="space-y-3 mb-8">
              <div className="h-4 bg-dental-beige rounded"></div>
              <div className="h-4 bg-dental-beige rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !service) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="container mx-auto px-4 lg:px-8 py-16">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Service Not Found</h1>
              <p className="text-gray-600 mb-6">
                The service you're looking for doesn't exist or has been moved.
              </p>
              <Link href="/services">
                <Button>Back to Services</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const IconComponent = serviceIcons[service.icon as keyof typeof serviceIcons] || Heart;

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Breadcrumb */}
      <div className="bg-dental-beige py-4">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-dental-grey hover:text-dental-dark">Home</Link>
            <span className="text-dental-grey">/</span>
            <Link href="/services" className="text-dental-grey hover:text-dental-dark">Services</Link>
            <span className="text-dental-grey">/</span>
            <span className="text-dental-dark font-medium">{service.title}</span>
          </div>
        </div>
      </div>

      {/* Service Header */}
      <section className="py-16 lg:py-24 bg-gradient-to-br from-white via-dental-beige to-dental-beige-light">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <Link href="/services">
              <Button variant="ghost" className="mb-6 text-dental-grey hover:text-dental-dark">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Services
              </Button>
            </Link>
            
            <div className="flex items-center mb-6">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mr-6 shadow-lg">
                <IconComponent className="text-dental-dark h-8 w-8" />
              </div>
              <div>
                <h1 className="text-4xl lg:text-5xl font-bold text-dental-dark">
                  {service.title}
                </h1>
              </div>
            </div>
            
            <p className="text-xl text-dental-text leading-relaxed">
              {service.description}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Service Details */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Service Image */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <img
                src={service.imageUrl}
                alt={service.title}
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
            </motion.div>

            {/* Service Features */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-3xl font-bold text-dental-dark mb-6">
                  What We Offer
                </h2>
                <div className="grid gap-4">
                  {service.features.map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                      className="flex items-center space-x-3"
                    >
                      <CheckCircle className="text-dental-dark h-5 w-5 flex-shrink-0" />
                      <span className="text-dental-text">{feature}</span>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="bg-dental-beige rounded-2xl p-6">
                <h3 className="text-xl font-semibold text-dental-dark mb-4">
                  Ready to Get Started?
                </h3>
                <p className="text-dental-text mb-4">
                  Schedule a consultation with our expert team to discuss your specific needs 
                  and create a personalized treatment plan.
                </p>
                <div className="bg-white rounded-lg p-4 mb-6">
                  <div className="grid grid-cols-2 gap-2 text-sm text-dental-grey">
                    <p>✓ Free consultation</p>
                    <p>✓ Written quotations</p>
                    <p>✓ Payment plans available</p>
                    <p>✓ Insurance accepted</p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button variant="primary" className="w-full sm:w-auto" asChild>
                    <Link href="/contact">
                      Book Free Consultation
                    </Link>
                  </Button>
                  <Button 
                    variant="call" 
                    className="w-full sm:w-auto"
                    onClick={() => window.open('tel:02086429345', '_self')}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Call 0208 642 9345 for Pricing
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 lg:py-24 bg-dental-beige">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-6">
              Why Choose SmileCare for {service.title}?
            </h2>
            <p className="text-lg text-dental-text max-w-3xl mx-auto">
              Our commitment to excellence and patient-centered care makes us the trusted choice 
              for your dental needs.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Stethoscope className="text-dental-dark h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-dental-dark mb-3">Expert Care</h3>
              <p className="text-dental-text">
                Our experienced team uses the latest techniques and technology to ensure the best possible outcomes.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Smile className="text-dental-dark h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-dental-dark mb-3">Comfort First</h3>
              <p className="text-dental-text">
                We prioritize your comfort with a relaxing environment and gentle, pain-free treatments.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <CheckCircle className="text-dental-dark h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-dental-dark mb-3">Proven Results</h3>
              <p className="text-dental-text">
                With over 15 years of experience and thousands of satisfied patients, we deliver exceptional results.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
