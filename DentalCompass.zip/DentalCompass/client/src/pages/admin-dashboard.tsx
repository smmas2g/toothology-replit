import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { 
  Users, 
  Calendar, 
  FileText, 
  DollarSign, 
  TrendingUp,
  Clock,
  Phone,
  Mail,
  AlertCircle,
  CheckCircle,
  BarChart3,
  Settings,
  Plus,
  Eye,
  Edit,
  Trash2
} from "lucide-react";
import type { ContactSubmission, BlogPost, Testimonial } from "@shared/schema";

const mockDashboardData = {
  stats: {
    totalPatients: 1247,
    todayAppointments: 12,
    thisMonthRevenue: 34500,
    pendingTasks: 8
  },
  todayAppointments: [
    {
      id: 1,
      time: "9:00 AM",
      patient: "John Smith",
      type: "Routine Cleaning",
      doctor: "Dr. Johnson",
      status: "Confirmed"
    },
    {
      id: 2,
      time: "10:30 AM",
      patient: "Sarah Wilson",
      type: "Dental Exam",
      doctor: "Dr. Chen",
      status: "Checked In"
    },
    {
      id: 3,
      time: "2:00 PM",
      patient: "Mike Johnson",
      type: "Root Canal",
      doctor: "Dr. Johnson",
      status: "Confirmed"
    }
  ],
  recentPatients: [
    {
      id: 1,
      name: "Emma Davis",
      email: "emma@email.com",
      phone: "(555) 123-4567",
      lastVisit: "2024-07-15",
      status: "Active"
    },
    {
      id: 2,
      name: "Robert Brown",
      email: "robert@email.com",
      phone: "(555) 987-6543",
      lastVisit: "2024-07-10",
      status: "Active"
    }
  ]
};

export default function AdminDashboard() {
  const { data: contactSubmissions } = useQuery<ContactSubmission[]>({
    queryKey: ["/api/contact/submissions"],
  });

  const { data: blogPosts } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog"],
  });

  const { data: testimonials } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Header */}
      <section className="bg-gradient-to-br from-white via-dental-beige to-dental-beige-light py-12">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col md:flex-row justify-between items-start md:items-center"
          >
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-2">
                Admin Dashboard
              </h1>
              <p className="text-dental-text">
                Manage your practice, appointments, and patient communications
              </p>
            </div>
            <div className="flex space-x-3 mt-4 md:mt-0">
              <Button className="bg-dental-dark text-white hover:bg-dental-grey">
                <Plus className="mr-2 h-4 w-4" />
                New Appointment
              </Button>
              <Button variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Dashboard Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <Tabs defaultValue="overview" className="space-y-8">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-6 bg-dental-beige">
              <TabsTrigger value="overview" className="data-[state=active]:bg-white">Overview</TabsTrigger>
              <TabsTrigger value="appointments" className="data-[state=active]:bg-white">Appointments</TabsTrigger>
              <TabsTrigger value="patients" className="data-[state=active]:bg-white">Patients</TabsTrigger>
              <TabsTrigger value="messages" className="data-[state=active]:bg-white">Messages</TabsTrigger>
              <TabsTrigger value="content" className="data-[state=active]:bg-white">Content</TabsTrigger>
              <TabsTrigger value="reports" className="data-[state=active]:bg-white">Reports</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-8">
              {/* Stats Cards */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
              >
                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-dental-grey text-sm font-medium">Total Patients</p>
                        <p className="text-3xl font-bold text-dental-dark">{mockDashboardData.stats.totalPatients}</p>
                      </div>
                      <Users className="h-8 w-8 text-dental-dark" />
                    </div>
                    <div className="flex items-center mt-4 text-sm">
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">+12%</span>
                      <span className="text-dental-grey ml-1">from last month</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-dental-grey text-sm font-medium">Today's Appointments</p>
                        <p className="text-3xl font-bold text-dental-dark">{mockDashboardData.stats.todayAppointments}</p>
                      </div>
                      <Calendar className="h-8 w-8 text-dental-dark" />
                    </div>
                    <div className="flex items-center mt-4 text-sm">
                      <Clock className="h-4 w-4 text-blue-500 mr-1" />
                      <span className="text-dental-grey">Next: 9:00 AM</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-dental-grey text-sm font-medium">Monthly Revenue</p>
                        <p className="text-3xl font-bold text-dental-dark">${mockDashboardData.stats.thisMonthRevenue.toLocaleString()}</p>
                      </div>
                      <DollarSign className="h-8 w-8 text-dental-dark" />
                    </div>
                    <div className="flex items-center mt-4 text-sm">
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">+8%</span>
                      <span className="text-dental-grey ml-1">from last month</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-dental-grey text-sm font-medium">Pending Tasks</p>
                        <p className="text-3xl font-bold text-dental-dark">{mockDashboardData.stats.pendingTasks}</p>
                      </div>
                      <AlertCircle className="h-8 w-8 text-dental-dark" />
                    </div>
                    <div className="flex items-center mt-4 text-sm">
                      <span className="text-dental-grey">Review required</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Today's Appointments & Recent Activity */}
              <div className="grid lg:grid-cols-2 gap-8">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                >
                  <Card className="rounded-2xl shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-dental-dark">Today's Appointments</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {mockDashboardData.todayAppointments.map((appointment) => (
                        <div key={appointment.id} className="flex items-center justify-between p-4 bg-dental-beige rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                              <Clock className="h-5 w-5 text-dental-dark" />
                            </div>
                            <div>
                              <p className="font-medium text-dental-dark">{appointment.patient}</p>
                              <p className="text-sm text-dental-text">{appointment.type}</p>
                              <p className="text-xs text-dental-grey">{appointment.time} • {appointment.doctor}</p>
                            </div>
                          </div>
                          <Badge 
                            variant={appointment.status === "Checked In" ? "default" : "outline"}
                            className={appointment.status === "Checked In" ? "bg-green-100 text-green-800" : ""}
                          >
                            {appointment.status}
                          </Badge>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                >
                  <Card className="rounded-2xl shadow-lg">
                    <CardHeader>
                      <CardTitle className="text-dental-dark">Recent Patients</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {mockDashboardData.recentPatients.map((patient) => (
                        <div key={patient.id} className="flex items-center justify-between p-4 bg-dental-beige rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                              <Users className="h-5 w-5 text-dental-dark" />
                            </div>
                            <div>
                              <p className="font-medium text-dental-dark">{patient.name}</p>
                              <p className="text-sm text-dental-text">{patient.email}</p>
                              <p className="text-xs text-dental-grey">Last visit: {new Date(patient.lastVisit).toLocaleDateString()}</p>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Messages Tab */}
            <TabsContent value="messages">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="rounded-2xl shadow-lg">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-dental-dark">Contact Submissions</CardTitle>
                    <Badge variant="outline" className="border-dental-dark text-dental-dark">
                      {contactSubmissions?.length || 0} Messages
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    {!contactSubmissions?.length ? (
                      <div className="text-center py-8">
                        <Mail className="h-12 w-12 text-dental-grey mx-auto mb-4" />
                        <p className="text-dental-text">No contact submissions yet</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {contactSubmissions.map((submission) => (
                          <div key={submission.id} className="p-4 bg-dental-beige rounded-lg">
                            <div className="flex items-center justify-between mb-3">
                              <div>
                                <p className="font-medium text-dental-dark">
                                  {submission.firstName} {submission.lastName}
                                </p>
                                <p className="text-sm text-dental-text">{submission.email}</p>
                              </div>
                              <div className="text-right">
                                <Badge 
                                  variant={submission.status === "new" ? "default" : "outline"}
                                  className={submission.status === "new" ? "bg-blue-100 text-blue-800" : ""}
                                >
                                  {submission.status}
                                </Badge>
                                <p className="text-xs text-dental-grey mt-1">
                                  {new Date(submission.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <div className="text-sm text-dental-text mb-3">
                              <p><strong>Service:</strong> {submission.service}</p>
                              <p><strong>Phone:</strong> {submission.phone}</p>
                            </div>
                            <p className="text-sm text-dental-text bg-white p-3 rounded">
                              {submission.message}
                            </p>
                            <div className="flex space-x-2 mt-3">
                              <Button size="sm" className="bg-dental-dark text-white hover:bg-dental-grey">
                                Reply
                              </Button>
                              <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                                Mark as Read
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Content Tab */}
            <TabsContent value="content">
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Blog Posts */}
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  <Card className="rounded-2xl shadow-lg">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle className="text-dental-dark">Blog Posts</CardTitle>
                      <Button size="sm" className="bg-dental-dark text-white hover:bg-dental-grey">
                        <Plus className="mr-2 h-4 w-4" />
                        New Post
                      </Button>
                    </CardHeader>
                    <CardContent>
                      {!blogPosts?.length ? (
                        <div className="text-center py-8">
                          <FileText className="h-12 w-12 text-dental-grey mx-auto mb-4" />
                          <p className="text-dental-text">No blog posts yet</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {blogPosts.slice(0, 3).map((post) => (
                            <div key={post.id} className="flex items-center justify-between p-4 bg-dental-beige rounded-lg">
                              <div className="flex-1">
                                <p className="font-medium text-dental-dark">{post.title}</p>
                                <p className="text-sm text-dental-text">{post.category}</p>
                                <p className="text-xs text-dental-grey">
                                  {new Date(post.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge variant={post.published ? "default" : "outline"}>
                                  {post.published ? "Published" : "Draft"}
                                </Badge>
                                <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Testimonials */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                >
                  <Card className="rounded-2xl shadow-lg">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle className="text-dental-dark">Testimonials</CardTitle>
                      <Button size="sm" className="bg-dental-dark text-white hover:bg-dental-grey">
                        <Plus className="mr-2 h-4 w-4" />
                        Add Review
                      </Button>
                    </CardHeader>
                    <CardContent>
                      {!testimonials?.length ? (
                        <div className="text-center py-8">
                          <CheckCircle className="h-12 w-12 text-dental-grey mx-auto mb-4" />
                          <p className="text-dental-text">No testimonials yet</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {testimonials.slice(0, 3).map((testimonial) => (
                            <div key={testimonial.id} className="p-4 bg-dental-beige rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <p className="font-medium text-dental-dark">{testimonial.patientName}</p>
                                <div className="flex items-center space-x-2">
                                  <div className="flex text-yellow-500">
                                    {[...Array(testimonial.rating)].map((_, i) => (
                                      <span key={i}>⭐</span>
                                    ))}
                                  </div>
                                  <Badge variant={testimonial.featured ? "default" : "outline"}>
                                    {testimonial.featured ? "Featured" : "Standard"}
                                  </Badge>
                                </div>
                              </div>
                              <p className="text-sm text-dental-text mb-2">"{testimonial.content}"</p>
                              <p className="text-xs text-dental-grey">{testimonial.treatment}</p>
                              <div className="flex space-x-2 mt-3">
                                <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Other tabs would have similar placeholder content */}
            <TabsContent value="appointments">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center py-16"
              >
                <Calendar className="h-16 w-16 text-dental-grey mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-dental-dark mb-4">Appointment Management</h3>
                <p className="text-dental-text mb-8">
                  This would contain a full calendar view with appointment scheduling, 
                  patient management, and booking functionality.
                </p>
                <Button className="bg-dental-dark text-white hover:bg-dental-grey">
                  View Full Calendar
                </Button>
              </motion.div>
            </TabsContent>

            <TabsContent value="patients">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center py-16"
              >
                <Users className="h-16 w-16 text-dental-grey mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-dental-dark mb-4">Patient Management</h3>
                <p className="text-dental-text mb-8">
                  Complete patient database with medical histories, treatment plans, 
                  and communication records.
                </p>
                <Button className="bg-dental-dark text-white hover:bg-dental-grey">
                  Manage Patients
                </Button>
              </motion.div>
            </TabsContent>

            <TabsContent value="reports">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center py-16"
              >
                <BarChart3 className="h-16 w-16 text-dental-grey mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-dental-dark mb-4">Analytics & Reports</h3>
                <p className="text-dental-text mb-8">
                  Comprehensive reporting on practice performance, revenue analytics, 
                  and patient satisfaction metrics.
                </p>
                <Button className="bg-dental-dark text-white hover:bg-dental-grey">
                  View Reports
                </Button>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <Footer />
    </div>
  );
}
