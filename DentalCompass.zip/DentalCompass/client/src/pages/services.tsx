import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { 
  Heart, 
  Smile, 
  User, 
  Stethoscope, 
  Baby, 
  Ambulance,
  ArrowRight
} from "lucide-react";
import type { Service } from "@shared/schema";

const serviceIcons = {
  "fas fa-tooth": Heart,
  "fas fa-smile": Smile,
  "fas fa-grip-lines": User,
  "fas fa-user-md": Stethoscope,
  "fas fa-child": Baby,
  "fas fa-ambulance": Ambulance,
};

export default function Services() {
  const { data: services, isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-white via-dental-beige to-dental-beige-light py-16 lg:py-24">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-dental-dark mb-6">
              Our <span className="text-dental-grey">Dental</span> Services
            </h1>
            <p className="text-lg lg:text-xl text-dental-text leading-relaxed">
              Comprehensive dental care tailored to your unique needs. From preventive care to complex procedures, 
              we provide exceptional service with the latest technology and techniques.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-dental-beige rounded-2xl p-8">
                  <div className="w-16 h-16 bg-dental-beige-light rounded-full mb-6"></div>
                  <div className="h-6 bg-dental-beige-light rounded mb-4"></div>
                  <div className="space-y-2 mb-6">
                    <div className="h-4 bg-dental-beige-light rounded"></div>
                    <div className="h-4 bg-dental-beige-light rounded w-3/4"></div>
                    <div className="h-4 bg-dental-beige-light rounded w-1/2"></div>
                  </div>
                  <div className="space-y-2 mb-6">
                    {[...Array(4)].map((_, j) => (
                      <div key={j} className="h-3 bg-dental-beige-light rounded w-3/4"></div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {services?.map((service, index) => {
                const IconComponent = serviceIcons[service.icon as keyof typeof serviceIcons] || Heart;
                return (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                  >
                    <Link href={`/services/${service.slug}`}>
                      <Card className="bg-dental-beige rounded-2xl hover:shadow-xl transition-all duration-300 group cursor-pointer h-full">
                        <CardContent className="p-8">
                          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                            <IconComponent className="text-dental-dark h-6 w-6" />
                          </div>
                          <h3 className="text-xl font-semibold text-dental-dark mb-4">
                            {service.title}
                          </h3>
                          <p className="text-dental-text mb-6 leading-relaxed">
                            {service.description}
                          </p>
                          
                          {/* Features List */}
                          <div className="mb-6">
                            <h4 className="font-medium text-dental-dark mb-3">What we offer:</h4>
                            <ul className="space-y-1">
                              {service.features.slice(0, 3).map((feature, i) => (
                                <li key={i} className="text-sm text-dental-text flex items-center">
                                  <span className="w-1.5 h-1.5 bg-dental-dark rounded-full mr-2 flex-shrink-0"></span>
                                  {feature}
                                </li>
                              ))}
                              {service.features.length > 3 && (
                                <li className="text-sm text-dental-grey">
                                  +{service.features.length - 3} more services
                                </li>
                              )}
                            </ul>
                          </div>
                          
                          <div className="flex items-center text-dental-dark font-medium group-hover:translate-x-2 transition-transform duration-300">
                            Learn More <ArrowRight className="ml-2 h-4 w-4" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-24 bg-dental-beige">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-6">
              Ready to Transform Your Smile?
            </h2>
            <p className="text-lg text-dental-text mb-6 leading-relaxed">
              Our experienced team is here to help you achieve optimal oral health and the confident smile you deserve.
            </p>
            <div className="bg-white rounded-lg p-6 mb-8 max-w-2xl mx-auto">
              <div className="grid grid-cols-2 gap-4 text-sm text-dental-grey">
                <p>✓ Free consultation available</p>
                <p>✓ Written quotations after examination</p>
                <p>✓ Payment plans available</p>
                <p>✓ Insurance accepted</p>
              </div>
              <div className="text-center mt-4">
                <p className="font-medium text-dental-dark">
                  Call 0208 642 9345 for personalized pricing
                </p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="primary" size="lg" asChild>
                <Link href="/contact">
                  Book Free Consultation
                </Link>
              </Button>
              <Button 
                variant="call" 
                size="lg"
                onClick={() => window.open('tel:02086429345', '_self')}
              >
                Call 0208 642 9345
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
