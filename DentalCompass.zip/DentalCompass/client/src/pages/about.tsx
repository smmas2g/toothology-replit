import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Mail, Phone, User } from "lucide-react";
import type { TeamMember } from "@shared/schema";

export default function About() {
  const { data: teamMembers, isLoading } = useQuery<TeamMember[]>({
    queryKey: ["/api/team"],
  });

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-white via-dental-beige to-dental-beige-light py-16 lg:py-24">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-dental-dark mb-6">
              About <span className="text-dental-grey">SmileCare</span> Dental
            </h1>
            <p className="text-lg lg:text-xl text-dental-text leading-relaxed">
              For over 15 years, we've been dedicated to providing exceptional dental care 
              with a patient-first approach, modern technology, and a commitment to excellence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-6"
            >
              <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark">
                Our Story
              </h2>
              <p className="text-lg text-dental-text leading-relaxed">
                SmileCare Dental was founded with a simple mission: to provide exceptional dental care 
                in a comfortable, welcoming environment. What started as a small practice has grown into 
                a comprehensive dental center serving thousands of patients.
              </p>
              <p className="text-lg text-dental-text leading-relaxed">
                We believe that everyone deserves a healthy, beautiful smile. Our team combines years of 
                experience with the latest dental technology to deliver personalized care that exceeds expectations.
              </p>
              <p className="text-lg text-dental-text leading-relaxed">
                From routine cleanings to complex procedures, we're committed to making your dental experience 
                as comfortable and effective as possible.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="grid grid-cols-2 gap-4"
            >
              <img
                src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Modern dental office"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
              <img
                src="https://images.unsplash.com/photo-1612277795421-9bc7706a4a34?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Advanced dental equipment"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
              <img
                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Patient consultation"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
              <img
                src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                alt="Clean treatment room"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 lg:py-24 bg-dental-beige">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-6">
              Our Values
            </h2>
            <p className="text-lg text-dental-text max-w-3xl mx-auto">
              These core values guide everything we do and ensure that every patient 
              receives the highest quality care.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white rounded-2xl shadow-lg h-full">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-dental-beige rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-dental-dark text-2xl">🤝</span>
                  </div>
                  <h3 className="text-xl font-semibold text-dental-dark mb-4">
                    Patient-Centered Care
                  </h3>
                  <p className="text-dental-text">
                    Your comfort, concerns, and goals are at the heart of everything we do. 
                    We listen, understand, and create personalized treatment plans.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white rounded-2xl shadow-lg h-full">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-dental-beige rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-dental-dark text-2xl">⚡</span>
                  </div>
                  <h3 className="text-xl font-semibold text-dental-dark mb-4">
                    Innovation & Excellence
                  </h3>
                  <p className="text-dental-text">
                    We stay at the forefront of dental technology and techniques to provide 
                    the most effective, comfortable treatments available.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white rounded-2xl shadow-lg h-full">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-dental-beige rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-dental-dark text-2xl">💚</span>
                  </div>
                  <h3 className="text-xl font-semibold text-dental-dark mb-4">
                    Integrity & Trust
                  </h3>
                  <p className="text-dental-text">
                    We build lasting relationships through honest communication, 
                    transparent treatment options, and ethical practice.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-6">
              Meet Our Expert Team
            </h2>
            <p className="text-lg text-dental-text max-w-3xl mx-auto">
              Our experienced professionals are dedicated to providing you with the highest 
              quality dental care in a comfortable, welcoming environment.
            </p>
          </motion.div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-8">
                    <div className="w-32 h-32 bg-dental-beige-light rounded-full mx-auto mb-6"></div>
                    <div className="h-6 bg-dental-beige-light rounded mb-3"></div>
                    <div className="h-4 bg-dental-beige-light rounded mb-4 w-3/4 mx-auto"></div>
                    <div className="space-y-2 mb-6">
                      <div className="h-3 bg-dental-beige-light rounded"></div>
                      <div className="h-3 bg-dental-beige-light rounded w-5/6"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {teamMembers?.map((member, index) => (
                <motion.div
                  key={member.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="bg-dental-beige rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 h-full">
                    <CardContent className="p-8 text-center">
                      <img
                        src={member.imageUrl}
                        alt={member.name}
                        className="w-32 h-32 rounded-full object-cover mx-auto mb-6 shadow-lg"
                      />
                      <h3 className="text-xl font-semibold text-dental-dark mb-2">
                        {member.name}
                      </h3>
                      <p className="text-dental-grey font-medium mb-4">
                        {member.position}
                      </p>
                      <p className="text-dental-text text-sm mb-6 leading-relaxed">
                        {member.bio}
                      </p>
                      
                      {/* Specialties */}
                      <div className="mb-6">
                        <h4 className="font-medium text-dental-dark mb-2">Specialties:</h4>
                        <div className="flex flex-wrap justify-center gap-2">
                          {member.specialties.map((specialty, i) => (
                            <span
                              key={i}
                              className="bg-white px-3 py-1 rounded-full text-xs text-dental-dark"
                            >
                              {specialty}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Experience */}
                      <div className="mb-6">
                        <p className="text-sm text-dental-grey">
                          <strong>{member.experience}</strong> of experience
                        </p>
                      </div>

                      {/* Contact */}
                      <div className="flex justify-center space-x-4">
                        {member.email && (
                          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                            <Mail className="h-4 w-4 text-dental-dark" />
                          </div>
                        )}
                        {member.phone && (
                          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                            <Phone className="h-4 w-4 text-dental-dark" />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 lg:py-24 bg-dental-beige">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="grid md:grid-cols-4 gap-8 text-center"
          >
            <div>
              <div className="text-4xl font-bold text-dental-dark mb-2">15+</div>
              <div className="text-dental-grey">Years of Excellence</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-dental-dark mb-2">5000+</div>
              <div className="text-dental-grey">Happy Patients</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-dental-dark mb-2">10000+</div>
              <div className="text-dental-grey">Procedures Completed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-dental-dark mb-2">4.9</div>
              <div className="text-dental-grey">Average Rating</div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
