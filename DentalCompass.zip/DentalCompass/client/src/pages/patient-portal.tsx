import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { useState } from "react";
import { 
  User, 
  Calendar, 
  FileText, 
  CreditCard, 
  Clock, 
  Phone,
  Mail,
  MapPin,
  Lock,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle,
  Download
} from "lucide-react";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const mockPatientData = {
  name: "John Doe",
  email: "john.doe@email.com",
  phone: "(555) 123-4567",
  address: "123 Main St, Your City, ST 12345",
  dateOfBirth: "1985-03-15",
  nextAppointment: {
    date: "2024-08-15",
    time: "2:00 PM",
    type: "Routine Cleaning",
    doctor: "Dr. Sarah Johnson"
  },
  recentAppointments: [
    {
      id: 1,
      date: "2024-07-10",
      type: "Routine Cleaning",
      doctor: "Dr. Sarah Johnson",
      status: "Completed"
    },
    {
      id: 2,
      date: "2024-04-15",
      type: "Dental Exam",
      doctor: "Dr. Sarah Johnson",
      status: "Completed"
    }
  ],
  documents: [
    {
      id: 1,
      name: "Treatment Plan - July 2024",
      type: "Treatment Plan",
      date: "2024-07-10"
    },
    {
      id: 2,
      name: "X-Ray Results - April 2024",
      type: "X-Ray",
      date: "2024-04-15"
    }
  ],
  billing: [
    {
      id: 1,
      date: "2024-07-10",
      description: "Routine Cleaning",
      amount: "$150.00",
      status: "Paid"
    },
    {
      id: 2,
      date: "2024-04-15",
      description: "Dental Exam",
      amount: "$200.00",
      status: "Paid"
    }
  ]
};

type LoginFormData = z.infer<typeof loginSchema>;

export default function PatientPortal() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    // Simulate login process
    setTimeout(() => {
      setIsLoggedIn(true);
      setIsLoading(false);
    }, 1500);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        
        {/* Login Section */}
        <section className="py-16 lg:py-24 bg-gradient-to-br from-white via-dental-beige to-dental-beige-light min-h-screen flex items-center">
          <div className="container mx-auto px-4 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-md mx-auto"
            >
              <Card className="bg-white rounded-2xl shadow-2xl">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-dental-beige rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="text-dental-dark h-8 w-8" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-dental-dark">
                    Patient Portal Login
                  </CardTitle>
                  <p className="text-dental-text">
                    Access your appointments, documents, and billing information
                  </p>
                </CardHeader>
                <CardContent className="p-6">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <FormField
                        control={form.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-dental-dark">Username or Email</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter your username or email"
                                {...field}
                                className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-dental-dark">Password</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input
                                  type={showPassword ? "text" : "password"}
                                  placeholder="Enter your password"
                                  {...field}
                                  className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark pr-10"
                                />
                                <button
                                  type="button"
                                  onClick={() => setShowPassword(!showPassword)}
                                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-dental-grey hover:text-dental-dark"
                                >
                                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                </button>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-dental-dark text-white hover:bg-dental-grey font-semibold py-3"
                      >
                        {isLoading ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Signing In...
                          </>
                        ) : (
                          <>
                            <Lock className="mr-2 h-4 w-4" />
                            Sign In
                          </>
                        )}
                      </Button>
                    </form>
                  </Form>

                  <div className="mt-6 space-y-4">
                    <div className="text-center">
                      <Button variant="link" className="text-dental-dark hover:text-dental-grey">
                        Forgot Password?
                      </Button>
                    </div>
                    
                    <div className="text-center text-sm text-dental-text">
                      Don't have an account?{" "}
                      <Button variant="link" className="text-dental-dark hover:text-dental-grey p-0">
                        Contact our office to register
                      </Button>
                    </div>
                  </div>

                  {/* Demo Note */}
                  <div className="mt-6 p-4 bg-dental-beige rounded-lg">
                    <p className="text-sm text-dental-text text-center">
                      <strong>Demo Mode:</strong> Use any username and password to access the patient portal
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Welcome Header */}
      <section className="bg-gradient-to-br from-white via-dental-beige to-dental-beige-light py-12">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col md:flex-row justify-between items-start md:items-center"
          >
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-2">
                Welcome back, {mockPatientData.name}!
              </h1>
              <p className="text-dental-text">
                Manage your appointments, view documents, and access your dental records
              </p>
            </div>
            <Button
              onClick={() => setIsLoggedIn(false)}
              variant="outline"
              className="mt-4 md:mt-0 border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white"
            >
              Sign Out
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Dashboard Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <Tabs defaultValue="overview" className="space-y-8">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 bg-dental-beige">
              <TabsTrigger value="overview" className="data-[state=active]:bg-white">Overview</TabsTrigger>
              <TabsTrigger value="appointments" className="data-[state=active]:bg-white">Appointments</TabsTrigger>
              <TabsTrigger value="documents" className="data-[state=active]:bg-white">Documents</TabsTrigger>
              <TabsTrigger value="billing" className="data-[state=active]:bg-white">Billing</TabsTrigger>
              <TabsTrigger value="profile" className="data-[state=active]:bg-white">Profile</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {/* Next Appointment */}
                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <Calendar className="text-dental-dark h-6 w-6 mr-3" />
                      <h3 className="font-semibold text-dental-dark">Next Appointment</h3>
                    </div>
                    <div className="space-y-2">
                      <p className="text-lg font-medium text-dental-dark">
                        {new Date(mockPatientData.nextAppointment.date).toLocaleDateString('en-US', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </p>
                      <p className="text-dental-text">{mockPatientData.nextAppointment.time}</p>
                      <p className="text-dental-text">{mockPatientData.nextAppointment.type}</p>
                      <p className="text-sm text-dental-grey">with {mockPatientData.nextAppointment.doctor}</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-dental-dark mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                      <Button variant="outline" className="w-full justify-start border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                        <Calendar className="mr-2 h-4 w-4" />
                        Schedule Appointment
                      </Button>
                      <Button variant="outline" className="w-full justify-start border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                        <Phone className="mr-2 h-4 w-4" />
                        Contact Office
                      </Button>
                      <Button variant="outline" className="w-full justify-start border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                        <FileText className="mr-2 h-4 w-4" />
                        View Documents
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Account Status */}
                <Card className="bg-dental-beige rounded-2xl shadow-lg">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-dental-dark mb-4">Account Status</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <CheckCircle className="text-green-500 h-4 w-4 mr-2" />
                        <span className="text-sm text-dental-text">Insurance Verified</span>
                      </div>
                      <div className="flex items-center">
                        <CheckCircle className="text-green-500 h-4 w-4 mr-2" />
                        <span className="text-sm text-dental-text">No Outstanding Balance</span>
                      </div>
                      <div className="flex items-center">
                        <AlertCircle className="text-yellow-500 h-4 w-4 mr-2" />
                        <span className="text-sm text-dental-text">Cleaning Due Soon</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <Card className="rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-dental-dark">Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockPatientData.recentAppointments.map((appointment) => (
                        <div key={appointment.id} className="flex items-center justify-between p-4 bg-dental-beige rounded-lg">
                          <div className="flex items-center space-x-4">
                            <Calendar className="text-dental-dark h-5 w-5" />
                            <div>
                              <p className="font-medium text-dental-dark">{appointment.type}</p>
                              <p className="text-sm text-dental-text">
                                {new Date(appointment.date).toLocaleDateString()} • {appointment.doctor}
                              </p>
                            </div>
                          </div>
                          <Badge variant={appointment.status === "Completed" ? "default" : "secondary"}>
                            {appointment.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Appointments Tab */}
            <TabsContent value="appointments">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="rounded-2xl shadow-lg">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle className="text-dental-dark">Your Appointments</CardTitle>
                    <Button className="bg-dental-dark text-white hover:bg-dental-grey">
                      <Calendar className="mr-2 h-4 w-4" />
                      Schedule New
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Upcoming Appointment */}
                    <div className="p-6 bg-gradient-to-r from-dental-beige to-dental-beige-light rounded-xl border-l-4 border-dental-dark">
                      <div className="flex items-center justify-between mb-4">
                        <Badge className="bg-dental-dark text-white">Upcoming</Badge>
                        <span className="text-sm text-dental-grey">
                          {new Date(mockPatientData.nextAppointment.date).toLocaleDateString()}
                        </span>
                      </div>
                      <h3 className="text-xl font-semibold text-dental-dark mb-2">
                        {mockPatientData.nextAppointment.type}
                      </h3>
                      <div className="grid md:grid-cols-3 gap-4 text-sm text-dental-text">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2" />
                          {mockPatientData.nextAppointment.time}
                        </div>
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-2" />
                          {mockPatientData.nextAppointment.doctor}
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                            Reschedule
                          </Button>
                          <Button size="sm" variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Past Appointments */}
                    <div>
                      <h3 className="text-lg font-semibold text-dental-dark mb-4">Past Appointments</h3>
                      <div className="space-y-3">
                        {mockPatientData.recentAppointments.map((appointment) => (
                          <div key={appointment.id} className="p-4 bg-dental-beige rounded-lg">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-dental-dark">{appointment.type}</p>
                                <p className="text-sm text-dental-text">
                                  {new Date(appointment.date).toLocaleDateString()} • {appointment.doctor}
                                </p>
                              </div>
                              <Badge variant="outline" className="border-green-500 text-green-500">
                                {appointment.status}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Documents Tab */}
            <TabsContent value="documents">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-dental-dark">Your Documents</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockPatientData.documents.map((document) => (
                        <div key={document.id} className="flex items-center justify-between p-4 bg-dental-beige rounded-lg">
                          <div className="flex items-center space-x-4">
                            <FileText className="text-dental-dark h-5 w-5" />
                            <div>
                              <p className="font-medium text-dental-dark">{document.name}</p>
                              <p className="text-sm text-dental-text">
                                {document.type} • {new Date(document.date).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <Button size="sm" variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Billing Tab */}
            <TabsContent value="billing">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-dental-dark">Billing & Payments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Account Summary */}
                      <div className="p-6 bg-dental-beige rounded-xl">
                        <h3 className="text-lg font-semibold text-dental-dark mb-4">Account Summary</h3>
                        <div className="grid md:grid-cols-3 gap-4">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-green-600">$0.00</p>
                            <p className="text-sm text-dental-grey">Outstanding Balance</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold text-dental-dark">$350.00</p>
                            <p className="text-sm text-dental-grey">YTD Payments</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold text-dental-dark">$150.00</p>
                            <p className="text-sm text-dental-grey">Last Payment</p>
                          </div>
                        </div>
                      </div>

                      {/* Payment History */}
                      <div>
                        <h3 className="text-lg font-semibold text-dental-dark mb-4">Payment History</h3>
                        <div className="space-y-3">
                          {mockPatientData.billing.map((payment) => (
                            <div key={payment.id} className="flex items-center justify-between p-4 bg-dental-beige rounded-lg">
                              <div className="flex items-center space-x-4">
                                <CreditCard className="text-dental-dark h-5 w-5" />
                                <div>
                                  <p className="font-medium text-dental-dark">{payment.description}</p>
                                  <p className="text-sm text-dental-text">
                                    {new Date(payment.date).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold text-dental-dark">{payment.amount}</p>
                                <Badge variant="outline" className="border-green-500 text-green-500">
                                  {payment.status}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="rounded-2xl shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-dental-dark">Your Profile</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Personal Information */}
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-dental-dark">Personal Information</h3>
                        <div className="space-y-3">
                          <div className="flex items-center space-x-3">
                            <User className="text-dental-dark h-5 w-5" />
                            <div>
                              <p className="font-medium text-dental-dark">{mockPatientData.name}</p>
                              <p className="text-sm text-dental-grey">Full Name</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Mail className="text-dental-dark h-5 w-5" />
                            <div>
                              <p className="font-medium text-dental-dark">{mockPatientData.email}</p>
                              <p className="text-sm text-dental-grey">Email Address</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Phone className="text-dental-dark h-5 w-5" />
                            <div>
                              <p className="font-medium text-dental-dark">{mockPatientData.phone}</p>
                              <p className="text-sm text-dental-grey">Phone Number</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <MapPin className="text-dental-dark h-5 w-5" />
                            <div>
                              <p className="font-medium text-dental-dark">{mockPatientData.address}</p>
                              <p className="text-sm text-dental-grey">Address</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-dental-dark">Medical Information</h3>
                        <div className="space-y-3">
                          <div>
                            <p className="font-medium text-dental-dark">
                              {new Date(mockPatientData.dateOfBirth).toLocaleDateString()}
                            </p>
                            <p className="text-sm text-dental-grey">Date of Birth</p>
                          </div>
                          <div>
                            <p className="font-medium text-dental-dark">No known allergies</p>
                            <p className="text-sm text-dental-grey">Allergies</p>
                          </div>
                          <div>
                            <p className="font-medium text-dental-dark">Blue Cross Blue Shield</p>
                            <p className="text-sm text-dental-grey">Insurance Provider</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      <Button className="bg-dental-dark text-white hover:bg-dental-grey">
                        Update Profile
                      </Button>
                      <Button variant="outline" className="border-dental-dark text-dental-dark hover:bg-dental-dark hover:text-white">
                        Change Password
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <Footer />
    </div>
  );
}
