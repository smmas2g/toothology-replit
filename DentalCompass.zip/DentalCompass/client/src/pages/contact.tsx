import Navigation from "@/components/ui/navigation";
import Footer from "@/components/ui/footer";
import GoogleMaps from "@/components/ui/google-maps";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  Send
} from "lucide-react";
import { contactFormSchema, type ContactFormData } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Contact() {
  const { toast } = useToast();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      service: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Message Sent Successfully!",
        description: data.message || "We'll get back to you soon.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/contact/submissions"] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error Sending Message",
        description: error.message || "Please try again later.",
      });
    },
  });

  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-white via-dental-beige to-dental-beige-light py-16 lg:py-24">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-dental-dark mb-6">
              Get In <span className="text-dental-grey">Touch</span>
            </h1>
            <p className="text-lg lg:text-xl text-dental-text leading-relaxed">
              Ready to start your journey to a healthier, more beautiful smile? 
              Contact us today to schedule your appointment or ask any questions.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Form and Info */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Card className="bg-dental-beige rounded-2xl shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl font-semibold text-dental-dark">
                    Send Us a Message
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-dental-dark">First Name</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="John"
                                  {...field}
                                  className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-dental-dark">Last Name</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Doe"
                                  {...field}
                                  className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-dental-dark">Email</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="john@example.com"
                                {...field}
                                className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-dental-dark">Phone</FormLabel>
                            <FormControl>
                              <Input
                                type="tel"
                                placeholder="(555) 123-4567"
                                {...field}
                                className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="service"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-dental-dark">Service Interested In</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark">
                                  <SelectValue placeholder="Select a Service" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="General Dentistry">General Dentistry</SelectItem>
                                <SelectItem value="Cosmetic Dentistry">Cosmetic Dentistry</SelectItem>
                                <SelectItem value="Orthodontics">Orthodontics</SelectItem>
                                <SelectItem value="Oral Surgery">Oral Surgery</SelectItem>
                                <SelectItem value="Pediatric Dentistry">Pediatric Dentistry</SelectItem>
                                <SelectItem value="Emergency Care">Emergency Care</SelectItem>
                                <SelectItem value="Consultation">General Consultation</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-dental-dark">Message</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Tell us about your dental needs and any questions you have..."
                                rows={4}
                                {...field}
                                className="border-dental-beige-light focus:ring-dental-dark focus:border-dental-dark"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        disabled={contactMutation.isPending}
                        className="w-full bg-dental-dark text-white hover:bg-dental-grey font-semibold text-lg py-4"
                      >
                        {contactMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send className="mr-2 h-4 w-4" />
                            Send Message
                          </>
                        )}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-8"
            >
              <div>
                <h2 className="text-3xl font-semibold text-dental-dark mb-8">
                  Visit Our Office
                </h2>
                <div className="space-y-6">
                  {/* Address */}
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-dental-beige rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="text-dental-dark h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-dental-dark mb-1">Address</h3>
                      <p className="text-dental-text">
                        125 Cheam Road<br />
                        Sutton, SM1 2BH
                      </p>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-dental-beige rounded-full flex items-center justify-center flex-shrink-0">
                      <Phone className="text-dental-dark h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-dental-dark mb-1">Phone</h3>
                      <p className="text-dental-text">
                        <a href="tel:02086429345" className="hover:text-dental-dark transition-colors">
                          0208 642 9345
                        </a>
                      </p>
                    </div>
                  </div>

                  {/* Email */}
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-dental-beige rounded-full flex items-center justify-center flex-shrink-0">
                      <Mail className="text-dental-dark h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-dental-dark mb-1">Email</h3>
                      <p className="text-dental-text">
                        <a href="mailto:admin@cheamdental.co.uk" className="hover:text-dental-dark transition-colors">
                          admin@cheamdental.co.uk
                        </a>
                      </p>
                    </div>
                  </div>

                  {/* Office Hours */}
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-dental-beige rounded-full flex items-center justify-center flex-shrink-0">
                      <Clock className="text-dental-dark h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-dental-dark mb-1">Office Hours</h3>
                      <div className="text-dental-text space-y-1">
                        <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                        <p>Saturday: 9:00 AM - 1:00 PM</p>
                        <p>Sunday: Closed</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              <Card className="bg-dental-beige rounded-2xl shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-dental-dark mb-3 flex items-center">
                    <AlertTriangle className="text-dental-dark mr-2 h-5 w-5" />
                    Emergency Care
                  </h3>
                  <p className="text-dental-text mb-4">
                    For dental emergencies outside of office hours, please call our emergency line:
                  </p>
                  <p className="font-semibold text-dental-dark text-lg">
                    <a href="tel:02086429345" className="hover:text-dental-grey transition-colors">
                      0208 642 9345
                    </a>
                  </p>
                </CardContent>
              </Card>

              {/* Google Maps */}
              <GoogleMaps 
                address="125 Cheam Road, Sutton, SM1 2BH"
                className="h-64"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 lg:py-24 bg-dental-beige">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-dental-dark mb-6">
              Why Choose Toothology Cheam Road?
            </h2>
            <p className="text-lg text-dental-text max-w-3xl mx-auto">
              We're committed to providing exceptional dental care in a comfortable, 
              welcoming environment with the latest technology and techniques.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: CheckCircle,
                title: "Expert Care",
                description: "Over 15 years of experience with the latest dental techniques and technology."
              },
              {
                icon: Clock,
                title: "Flexible Scheduling",
                description: "Convenient appointment times including evenings and weekends."
              },
              {
                icon: Phone,
                title: "Emergency Services",
                description: "24/7 emergency care for urgent dental situations."
              }
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="bg-white rounded-2xl shadow-lg text-center h-full">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-dental-beige rounded-full flex items-center justify-center mx-auto mb-6">
                      <benefit.icon className="text-dental-dark h-6 w-6" />
                    </div>
                    <h3 className="text-xl font-semibold text-dental-dark mb-4">
                      {benefit.title}
                    </h3>
                    <p className="text-dental-text">
                      {benefit.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
