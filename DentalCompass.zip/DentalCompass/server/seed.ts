import { db } from './db';
import { 
  services, 
  teamMembers, 
  testimonials, 
  galleryImages, 
  blogPosts,
  type InsertService,
  type InsertTeamMember,
  type InsertTestimonial,
  type InsertGalleryImage,
  type InsertBlogPost
} from '@shared/schema';

async function seed() {
  console.log('Starting database seeding...');

  // Seed services
  const servicesData: InsertService[] = [
    {
      title: "Invisalign",
      description: "Transform your smile with clear, removable aligners that gradually straighten your teeth without the need for traditional metal braces.",
      shortDescription: "Clear aligners for a straighter smile without traditional braces.",
      icon: "fas fa-smile",
      imageUrl: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      slug: "invisalign",
      features: ["Clear Aligners", "Removable", "Comfortable", "Discreet Treatment", "Faster Results", "Custom Fit"]
    },
    {
      title: "Dental Implants",
      description: "Permanent tooth replacement solution that looks, feels, and functions like natural teeth. Our implants restore your smile and confidence.",
      shortDescription: "Permanent tooth replacement that looks and feels natural.",
      icon: "fas fa-tooth",
      imageUrl: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      slug: "dental-implants",
      features: ["Permanent Solution", "Natural Appearance", "Bone Preservation", "Long-lasting", "Improved Function", "Enhanced Confidence"]
    },
    {
      title: "Cosmetic Dentistry",
      description: "Transform your smile with our aesthetic dental treatments including veneers, teeth whitening, and smile makeovers designed to enhance your natural beauty.",
      shortDescription: "Aesthetic treatments to enhance your natural smile beauty.",
      icon: "fas fa-star",
      imageUrl: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      slug: "cosmetic-dentistry",
      features: ["Teeth Whitening", "Porcelain Veneers", "Smile Makeovers", "Bonding", "Crown Lengthening", "Gum Contouring"]
    },
    {
      title: "Periodontics",
      description: "Specialized care for gum disease prevention and treatment. Our periodontal therapy helps maintain healthy gums and supporting structures.",
      shortDescription: "Specialized gum disease prevention and treatment.",
      icon: "fas fa-heartbeat",
      imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      slug: "periodontics",
      features: ["Gum Disease Treatment", "Deep Cleaning", "Scaling", "Root Planing", "Maintenance Therapy", "Prevention"]
    },
    {
      title: "Root Canal",
      description: "Save your natural tooth with advanced root canal therapy. Our gentle approach eliminates pain while preserving your tooth structure.",
      shortDescription: "Save your natural tooth with gentle root canal therapy.",
      icon: "fas fa-shield-alt",
      imageUrl: "https://images.unsplash.com/photo-1612277795421-9bc7706a4a34?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      slug: "root-canal",
      features: ["Pain Relief", "Tooth Preservation", "Advanced Technology", "Gentle Treatment", "Same-day Service", "High Success Rate"]
    },
    {
      title: "Dental Hygienist",
      description: "Professional dental cleanings and preventive care to maintain optimal oral health. Regular hygiene visits prevent problems before they start.",
      shortDescription: "Professional cleanings and preventive care for optimal oral health.",
      icon: "fas fa-user-md",
      imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      slug: "dental-hygienist",
      features: ["Professional Cleaning", "Fluoride Treatment", "Oral Health Education", "Plaque Removal", "Gum Health Assessment", "Preventive Care"]
    }
  ];

  await db.insert(services).values(servicesData);
  console.log('✓ Services seeded');

  // Seed team members
  const teamData: InsertTeamMember[] = [
    {
      name: "Dr. Sarah Johnson",
      position: "Lead Dentist & Practice Owner",
      bio: "Dr. Johnson has been providing exceptional dental care for over 15 years. She specializes in cosmetic and restorative dentistry with a focus on patient comfort and satisfaction.",
      imageUrl: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      specialties: ["Cosmetic Dentistry", "Restorative Dentistry", "Smile Makeovers"],
      education: ["DDS - University of Dental Medicine", "Residency in Cosmetic Dentistry"],
      experience: "15+ years",
      email: "dr.johnson@smilecare.com",
      phone: "(555) 123-4567"
    },
    {
      name: "Dr. Michael Chen",
      position: "Orthodontist",
      bio: "Dr. Chen is a board-certified orthodontist specializing in traditional braces and clear aligner therapy. He has helped thousands of patients achieve their perfect smile.",
      imageUrl: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      specialties: ["Orthodontics", "Invisalign", "Adult Braces"],
      education: ["DDS - Dental University", "MS in Orthodontics"],
      experience: "12+ years",
      email: "dr.chen@smilecare.com",
      phone: "(555) 123-4568"
    },
    {
      name: "Dr. Emily Rodriguez",
      position: "Pediatric Dentist",
      bio: "Dr. Rodriguez specializes in pediatric dentistry and loves working with children. She creates a fun, comfortable environment that helps kids develop positive associations with dental care.",
      imageUrl: "https://images.unsplash.com/photo-1594824022479-c8f86bd40de8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
      specialties: ["Pediatric Dentistry", "Preventive Care", "Behavior Management"],
      education: ["DDS - Children's Dental College", "Pediatric Dentistry Residency"],
      experience: "8+ years",
      email: "dr.rodriguez@smilecare.com",
      phone: "(555) 123-4569"
    }
  ];

  await db.insert(teamMembers).values(teamData);
  console.log('✓ Team members seeded');

  // Seed testimonials
  const testimonialsData: InsertTestimonial[] = [
    {
      patientName: "Sarah Johnson",
      rating: 5,
      content: "Dr. Johnson and the entire team at SmileCare made my dental experience comfortable and stress-free. The results exceeded my expectations!",
      treatment: "Cosmetic Dentistry",
      featured: true
    },
    {
      patientName: "Michael Chen",
      rating: 5,
      content: "Professional, caring, and thorough. My children actually look forward to their dental visits now. Highly recommended!",
      treatment: "Family Dentistry",
      featured: true
    },
    {
      patientName: "Emily Rodriguez",
      rating: 5,
      content: "The technology and techniques used here are amazing. My implant procedure was smooth and the results are perfect.",
      treatment: "Dental Implants",
      featured: true
    },
    {
      patientName: "David Thompson",
      rating: 5,
      content: "After years of being self-conscious about my smile, Dr. Johnson's cosmetic work has given me the confidence I never had.",
      treatment: "Smile Makeover",
      featured: false
    },
    {
      patientName: "Lisa Martinez",
      rating: 5,
      content: "The Invisalign treatment was exactly what I needed. Professional staff and excellent results!",
      treatment: "Invisalign",
      featured: false
    }
  ];

  await db.insert(testimonials).values(testimonialsData);
  console.log('✓ Testimonials seeded');

  // Seed gallery images
  const galleryData: InsertGalleryImage[] = [
    {
      title: "Smile Transformation",
      description: "Complete smile makeover with porcelain veneers",
      imageUrl: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      category: "Cosmetic Dentistry",
      featured: true
    },
    {
      title: "Modern Treatment Room",
      description: "State-of-the-art dental equipment and comfortable environment",
      imageUrl: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      category: "Facility",
      featured: true
    },
    {
      title: "Orthodontic Results",
      description: "Perfect smile alignment achieved with clear aligners",
      imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      category: "Orthodontics",
      featured: true
    },
    {
      title: "Dental Implant Success",
      description: "Natural-looking dental implant restoration",
      imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      category: "Dental Implants",
      featured: false
    }
  ];

  await db.insert(galleryImages).values(galleryData);
  console.log('✓ Gallery images seeded');

  // Seed blog posts
  const blogData: InsertBlogPost[] = [
    {
      title: "5 Tips for Maintaining Oral Health at Home",
      slug: "5-tips-oral-health-home",
      excerpt: "Learn essential daily habits that will keep your teeth and gums healthy between dental visits.",
      content: "Maintaining good oral health at home is crucial for your overall well-being. Here are five essential tips that will help you keep your teeth and gums healthy between dental visits...",
      imageUrl: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      author: "Dr. Sarah Johnson",
      category: "Oral Health",
      tags: ["Prevention", "Home Care", "Dental Hygiene"],
      published: true
    },
    {
      title: "The Latest in Cosmetic Dentistry: What's New in 2024",
      slug: "latest-cosmetic-dentistry-2024",
      excerpt: "Discover the cutting-edge treatments and technologies transforming smiles this year.",
      content: "Cosmetic dentistry continues to evolve with new technologies and techniques that make achieving your perfect smile easier than ever...",
      imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      author: "Dr. Michael Chen",
      category: "Cosmetic Dentistry",
      tags: ["Innovation", "Technology", "Smile Makeover"],
      published: true
    }
  ];

  await db.insert(blogPosts).values(blogData);
  console.log('✓ Blog posts seeded');

  console.log('Database seeding completed successfully!');
}

// Only run if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seed()
    .catch(console.error)
    .finally(() => process.exit());
}

export { seed };